<?php 
include('include/config.php');
include('include/functions.php');
//validate_admin();
if(!empty($_REQUEST ['user_id'])){
	$user_id=$_REQUEST['user_id'];
}else{
$user_id=$_SESSION['sess_admin_id'];
}
$query="select * from tbl_templates where user_id=$user_id";
$result=$mysqli->query($query);
$line=$result->fetch_object();
?>
	<!doctype html>
			<html>
			<head>
			<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
			<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
			<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.100.2/css/materialize.min.css">
			<link rel="stylesheet" href="css/style.css">
			<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.100.2/js/materialize.min.js"></script>
			<script>
			window.onload = function () {
			localStorage.setItem('gjs-css', <?php echo json_encode(html_entity_decode(htmlspecialchars_decode($line->css))); ?>);
			localStorage.setItem('gjs-html', <?php echo json_encode(html_entity_decode(htmlspecialchars_decode($line->html))); ?>);
			};
			</script>
			<style>
			<?php
			echo html_entity_decode(htmlspecialchars_decode($line->css));
			?>	
			</style>
			</head>
			<body>
			<?php
			echo html_entity_decode(htmlspecialchars_decode($line->html));
			?>
			</body>
			</html>
   


