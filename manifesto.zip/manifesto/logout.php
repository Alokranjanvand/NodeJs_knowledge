<?php
	include("include/config.php");
	include("include/functions.php");
	
	$_SESSION['sess_msg']='';
	$_SESSION['sess_admin_id']='';
	$_SESSION['sess_admin_username']='';
	$_SESSION['sess_admin_role']='';
	
	
session_destroy();
header("location: index.php");

?>