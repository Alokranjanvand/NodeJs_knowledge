<?php
	include("include/config.php");
	include("include/functions.php");
	validate_admin();
?>
<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
		<meta charset="utf-8" />
		<title><?php echo SITE_TITLE; ?></title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
		<meta content="" name="description" />
		<meta content="" name="author" />
		<script src="../../cdn-cgi/apps/head/QJpHOqznaMvNOv9CGoAdo_yvYKU.js"></script><link href="assets/plugins/font-awesome/css/font-awesome.css" rel="stylesheet" type="text/css" />
		<link href="assets/plugins/bootstrap-select2/select2.css" rel="stylesheet" type="text/css" media="screen" />
		<link href="assets/plugins/jquery-datatable/css/jquery.dataTables.css" rel="stylesheet" type="text/css" />
		<link href="assets/plugins/datatables-responsive/css/datatables.responsive.css" rel="stylesheet" type="text/css" media="screen" />
		<link href="assets/plugins/pace/pace-theme-flash.css" rel="stylesheet" type="text/css" media="screen" /> 
		<link href="assets/plugins/bootstrapv3/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
		<link href="assets/plugins/bootstrapv3/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css" />
		<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
		<link href="assets/plugins/animate.min.css" rel="stylesheet" type="text/css" />
		<link href="assets/plugins/jquery-scrollbar/jquery.scrollbar.css" rel="stylesheet" type="text/css" />
		<link href="webarch/css/webarch.css" rel="stylesheet" type="text/css" />
	</head>
	
	
	<body class="">
		<div class="header navbar navbar-inverse ">
			<div class="navbar-inner">
				<?php include('header.php');?>
				<div class="page-container row">
					<?php include('sidebar.php');?>
					<div class="page-content">
						<div id="portlet-config" class="modal hide">
							<div class="modal-header">
								<button data-dismiss="modal" class="close" type="button"></button>
								<h3>Widget Settings</h3>
							</div>
							<div class="modal-body"> Widget settings form goes here </div>
						</div>
						<div class="clearfix"></div>
						<div class="content">
							<ul class="breadcrumb">
								<li>
									<p>YOU ARE HERE</p>
								</li>
								<li><a href="#" class="active">View User</a> </li>
							</ul>
							<div class="row">
								<div class="col-md-12">
									<div class="grid simple form-grid">
										<div class="grid-title no-border">
											<div class="tools">
												<a href="add_user.php"><i class="material-icons">add_box</i></a>
												<a href="javascript:;" class="collapse"></a>
												<a href="javascript:;" class="reload"></a>
											</div>
										</div>
										<div class="grid-body no-border">
											<table class="table table-hover table-condensed" id="example">
												<thead>
													<?php if($_SESSION['successfully']){ ?>
														<tr><td  align="center" colspan="8">
															<font color="green"><strong><?php echo $_SESSION['successfully'];$_SESSION['successfully']='';?></strong></font>
														</td></tr>
													<?php }?>
													<tr>
														<th style="width:1%" nowrap>SN. </th>
														<th style="width:5%" nowrap>User Name </th>
														<th style="width:5%" nowrap>Email </th>
														<th style="width:5%" nowrap>Mobile </th>
														<th style="width:10%" nowrap>Role</th>
														<th style="width:10%" nowrap>Created Date </th>
														<th style="width:10%" nowrap>Modified Date</th>
														<th style="width:10%" nowrap>Action</th>
														
													</tr>
												</thead>
												<tbody>
													<?php 
														$q="select * from ".TBL_USER." where status=1 order by id desc";
														$result = $mysqli->query($q);
														$i=0;
														while($line=$result->fetch_object())
														{
															$i++;
															if($i%2==0)
															{
																$bgcolor = "#f3f4f6";
															}else
															{
																$bgcolor = "";
															}
														?>
														<tr bgcolor="<?php echo $bgcolor;?>">
															<td><?php echo $i; ?></td>
															
															<td><?php echo stripslashes($line->username);?></td>
															<td><?php echo stripslashes($line->email);?></td>
															<td><?php echo stripslashes($line->mobile);?></td>
															<td><?php 
																if($line->role_id=="1"){
																	echo "Super User";
																	}if($line->role_id=="2"){
																	echo "Editor";
																}
															?></td>
															<td><?php echo stripslashes($line->created_date);?></td>
															<td><?php echo stripslashes($line->modified_date);?></td>
															<td>
																<a title="Edit" href="add_user.php?id=<?php echo $line->id;?>" class="btn btn-info btn-info1"><i class="material-icons">border_color</i></a>
																<a title="Delete" href="javascript:void(0);" onclick="return del_prompt(<?php echo $line->id;?>)" class="btn btn-danger btn-info1"><i class="fa fa-trash"></i></a>
																<a title="View Website" href="show_page.php?user_id=<?php echo $line->id;?>"  class="btn btn-danger btn-info1" target="_blank"><i class="fa fa-eye"></i></a>
															</td>
														</tr>
														
													<?php } ?>
													
												</tbody>
											</table>
										</div>
									</div>
								</div>
							</div><!---row--->
						</div>
					</div>
					<script src="assets/plugins/pace/pace.min.js" type="text/javascript"></script>
					<script src="assets/plugins/jquery/jquery-1.11.3.min.js" type="text/javascript"></script>
					<script src="assets/plugins/bootstrapv3/js/bootstrap.min.js" type="text/javascript"></script>
					<script src="assets/plugins/jquery-block-ui/jqueryblockui.min.js" type="text/javascript"></script>
					<script src="assets/plugins/jquery-unveil/jquery.unveil.min.js" type="text/javascript"></script>
					<script src="assets/plugins/jquery-scrollbar/jquery.scrollbar.min.js" type="text/javascript"></script>
					<script src="assets/plugins/jquery-numberAnimate/jquery.animateNumbers.js" type="text/javascript"></script>
					<script src="assets/plugins/jquery-validation/js/jquery.validate.min.js" type="text/javascript"></script>
					<script src="assets/plugins/bootstrap-select2/select2.min.js" type="text/javascript"></script><script src="webarch/js/webarch.js" type="text/javascript"></script>
					<script src="assets/js/chat.js" type="text/javascript"></script><script src="assets/plugins/bootstrap-select2/select2.min.js" type="text/javascript"></script>
					<script src="assets/plugins/jquery-datatable/js/jquery.dataTables.min.js" type="text/javascript"></script>
				<script src="assets/plugins/jquery-datatable/extra/js/dataTables.tableTools.min.js" type="text/javascript"></script>
				<script type="text/javascript" src="assets/plugins/datatables-responsive/js/datatables.responsive.js"></script>
				<script type="text/javascript" src="assets/plugins/datatables-responsive/js/lodash.min.js"></script>
				<script src="assets/js/datatables.js" type="text/javascript"></script>
				<script>
				
				function del_prompt(value)
				{
				if(confirm ("Are you sure you want to delete record(s)"))
				{
				var url="pages_del.php"+value;
				window.location.href = url;
				}
				else{ 
				return false;
				}
				
				}
				
				
				</script>
				</body>
				</body>
				</html>																																																	