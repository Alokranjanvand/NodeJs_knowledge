<div class="page-sidebar " id="main-menu">
				
				<div class="page-sidebar-wrapper scrollbar-dynamic" id="main-menu-wrapper">
					
					<ul>
						
						<li class="start  open active ">
							<a href="dashboard.php"> 
								<i class="material-icons">home</i> 
								<span class="title">Dashboard</span> 
								
								</a>
						</li>
						<!--
						<li>
							<a href="view_pages.php"> <i class="material-icons">email</i> <span class="title">View Pages</span> 
							</a>
						</li>
						-->
						<li>
							<a href="view_user.php"> <i class="fa fa-user"></i> <span class="title">View User</span> <span class=" badge badge-disable pull-right "><?php echo getUser();?></span>
							</a>
						</li>
						<li>
							<a href="create_website.php" target="_blank"> <i class="fa fa-globe"></i> <span class="title">Create Website</span></a>
						</li>
						<li>
							<a href="show_page.php" target="_blank"> <i class="fa fa-internet-explorer"></i> <span class="title">View Website</span></a>
						</li>
						
					</ul>
					
					<div class="clearfix"></div>
					
				</div>
			</div>
			<a href="#" class="scrollup">Scroll</a>
			<div class="footer-widget">
				<div class="progress transparent progress-small no-radius no-margin">
					<div class="progress-bar progress-bar-success animate-progress-bar" data-percentage="79%" style="width: 79%;"></div>
				</div>
				<div class="pull-right">
					<div class="details-status"> <span class="animate-number" data-value="86" data-animation-duration="560">86</span>% </div>
				<a href="lockscreen.html"><i class="material-icons">power_settings_new</i></a></div>
			</div>