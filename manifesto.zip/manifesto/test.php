<?php 
include("include/config.php");
include("include/functions.php");
$pass="admin@123";
$password= EncryptPassword($pass );
echo $password;
?>							