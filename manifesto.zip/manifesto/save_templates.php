<?php 
include('include/config.php');
include('include/functions.php');
validate_admin();
$user_id=$_SESSION['sess_admin_id'];
$html =  $mysqli->real_escape_string($_POST["html"]);
$css =  $mysqli->real_escape_string($_POST["css"]); 
$user=checkTemplate($user_id);
if($user==0){
$q="insert into tbl_templates set html='$html',css='$css',user_id='$user_id',created_date=now(),status=1";
$mysqli->query($q);
echo"Save Templates";
}else{
$sql="update tbl_templates set  html='$html',css='$css',user_id='$user_id',modified_date=now(),status=1 where user_id='{$user_id}'";
$mysqli->query($sql);
echo"Updated Templates";
}
?>
   


