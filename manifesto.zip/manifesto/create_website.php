<?php 
	include('include/config.php');
	include('include/functions.php');
	validate_admin();
	$user_id=$_SESSION['sess_admin_id'];
	$query="select * from tbl_gallery where user_id='{$user_id}' order by id desc";
	$result=$mysqli->query($query);
    $query1="select * from tbl_templates where user_id='{$user_id}' order by id desc";
	$result1=$mysqli->query($query1);
    $line2=$result1->fetch_object();
	
?>
<!doctype html>
<html lang="en">
	
	<head>
		<meta charset="utf-8">
		<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
<meta http-equiv="Pragma" content="no-cache" />
<meta http-equiv="Expires" content="0"/>
		<title>Manifesto</title>
		<link rel="stylesheet" href="templates/dist/grapesjs/grapes.min.css">
		<link rel="stylesheet" href="templates/dist/gramateria/gram.min.css">
		
		<link rel="shortcut icon" href="favicon.ico" />
		<script src="templates/dist/grapesjs/grapes.min.js"></script>
		<script src="templates/dist/grapesjs/plugins/grapesjs-plugin-export.min.js"></script>
		
		<script>
			window.onload = function () {
			localStorage.setItem('gjs-css', <?php echo json_encode(html_entity_decode(htmlspecialchars_decode($line2->css))); ?>);
			localStorage.setItem('gjs-html', <?php echo json_encode(html_entity_decode(htmlspecialchars_decode($line2->html))); ?>);
			};
			</script>
		
	</head>
	<body>
		<div id="gjs" style="height:0px; overflow:hidden;">
			<style> </style>
		</div>
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
		<script type="text/javascript">
			var gallery_image=[
			<?php
				while($line=$result->fetch_object())
				{?>
				{
					type: 'image',
					src: '<?php echo "gallery/".$line->gallery;?>',
					date: '<?php echo date($line->created_date);?>',
					height: <?php echo $line->width;?>,
					width: <?php echo $line->height;?>
				},
			<?php } ?>
			
            {
                type: 'image',
                src: 'https://res.cloudinary.com/ronaldaug/image/upload/v1515419443/background_ckgyqe.jpg',
                date: '2015-02-01',
                height: 808,
                width: 1440
			},
            {
                type: 'image',
                src: 'https://res.cloudinary.com/ronaldaug/image/upload/v1515419441/background2_gjvaxs.jpg',
                date: '2015-02-01',
                height: 800,
                width: 1600
			},
            {
                type: 'image',
                src: 'https://res.cloudinary.com/ronaldaug/image/upload/v1515419443/background3_d0ghix.jpg',
                date: '2015-02-01',
                height: 743,
                width: 1440
			},
            {
                type: 'image',
                src: 'https://res.cloudinary.com/ronaldaug/image/upload/v1515419446/background4_pzh5ou.jpg',
                date: '2015-02-01',
                height: 808,
                width: 1440
			},
            {
                type: 'image',
                src: 'http://via.placeholder.com/250x350/0174DF/ffffff/',
                height: 350,
                width: 250
			},
            {
                type: 'image',
                src: 'http://via.placeholder.com/250x350/5FB404/ffffff/',
                height: 350,
                width: 250
			},
            {
                type: 'image',
                src: 'http://via.placeholder.com/250x350/BF00FF/ffffff/',
                height: 350,
                width: 250
			},
            {
                type: 'image',
                src: 'http://via.placeholder.com/250x350/B40431/ffffff/',
                height: 350,
                width: 250
			},
            {
                type: 'image',
                src: 'http://via.placeholder.com/250x350/088A68/ffffff/',
                height: 350,
                width: 250
			},
            {
                type: 'image',
                src: 'http://via.placeholder.com/250x350/DF7401/ffffff/',
                height: 350,
                width: 250
			},
            {
                type: 'image',
                src: 'http://via.placeholder.com/250x350/00BFFF/ffffff/',
                height: 350,
                width: 250
			}
			];
		</script>
		<script src="templates/gramateria.js?rev=<?php echo time();?>"></script>
		
		
		
	</body>
	
</html>
