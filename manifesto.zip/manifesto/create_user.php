<?php
	include("include/config.php");
	include("include/functions.php"); 
	$data = json_decode(file_get_contents("php://input"), true);

	// 1. Basic Validation
	$requiredFields = ['name', 'email', 'password', 'mobile'];
	$errors = [];

	foreach ($requiredFields as $field) {
		if (empty($data[$field])) {
			$errors[] = ucfirst($field) . " is required.";
		}
	}

	// Validate email format
	if (!empty($data['email']) && !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
		$errors[] = "Invalid email format.";
	}

	// Validate mobile (digits only, min 10 characters)
	if (!empty($data['mobile']) && !preg_match('/^\d{10,}$/', $data['mobile'])) {
		$errors[] = "Mobile number must be at least 10 digits.";
	}

	if (!empty($errors)) {
		echo json_encode(['status' => 'false', 'errors' => $errors]);
		exit;
	}
	$user_id       = $mysqli->real_escape_string(str_replace(' ', '_', $data['name']));
	$password      = $mysqli->real_escape_string(trim($data['password']));
	$user_name     = $user_id;
	$email_id      = $mysqli->real_escape_string(trim($data['email']));
	$mobile_no     = $mysqli->real_escape_string(trim($data['mobile']));
	$query="SELECT username,id FROM ".TBL_USER." WHERE username='$user_id' OR  mobile='$mobile_no' OR email='$email_id'";
	
	$sql=$mysqli->query($query);
	$result=$sql->fetch_array();
	$num_rows = $sql->num_rows;
	if ($num_rows>0) {
		echo json_encode(['status' => 'true', 'message' => 'User ID already exists.','main_id' => $result['id']]);
		exit;
	}else
	{
		$pwd= EncryptPassword($password);
		$query ="insert into ".TBL_USER." set username ='$user_name',email='$email_id',mobile='$mobile_no',password='$pwd',role_id='2',created_date=sysdate()";
		if ($mysqli->query($query)) {
			$last_id = $mysqli->insert_id;
			echo json_encode(['status' => 'true','message' => "Insert data successfully...!",'main_id' => $last_id]);
			exit;
		} else {
			echo json_encode(['status' => 'false','message' => "Unable to insert...!".$mysqli->error]);
			exit;
		}
	}

?>
