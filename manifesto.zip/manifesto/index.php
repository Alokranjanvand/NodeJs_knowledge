<?php 
include("include/config.php");
include("include/functions.php");

$username=$mysqli->real_escape_string($_POST['login_username']);
$pass=$mysqli->real_escape_string($_POST['login_pass']);
$password= EncryptPassword($pass);
if ($_POST['logged']=="yes" || $_GET['token']) {

	if(!empty($_GET['token']))
	{
		$token_id=$_GET['token'];
		$token=check_token_user($token_id);
		if($token==0)
		{
			echo "Invalid User";
			exit;
		}
		$query="select * from ".TBL_USER." where id='{$token}'";
		
	}else
	{
		$query="select * from ".TBL_USER." where email='{$username}' and password='{$password}'";
	}
    $result=$mysqli->query($query);
    if ($result->num_rows > 0) {
        $line=$result->fetch_object();
		$_SESSION['sess_admin_id']=$line->id;
		$_SESSION['sess_admin_username']=$line->username;
		$_SESSION['sess_admin_role']=$line->role_id;
        if($_REQUEST['back']=='') {
             header("location: dashboard.php");
        }
        else {
            header("location:".$_REQUEST['back']);
        }
    }
    else {
        $_SESSION['sess_msg']='Invalid Username/Password';
        header("Location: index.php");
    }
	exit;
}

?>
<!DOCTYPE html>
<html>
	
	<head>
		<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
		<meta charset="utf-8" />
		<title><?php echo SITE_TITLE; ?></title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
		<meta content="" name="description" />
		<meta content="" name="author" />
		
		<script src="../../cdn-cgi/apps/head/QJpHOqznaMvNOv9CGoAdo_yvYKU.js"></script>
		<link href="assets/plugins/pace/pace-theme-flash.css" rel="stylesheet" type="text/css" media="screen" />
		<link href="assets/plugins/bootstrapv3/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
		<link href="assets/plugins/bootstrapv3/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css" />
		<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
		<link href="assets/plugins/animate.min.css" rel="stylesheet" type="text/css" />
		<link href="assets/plugins/jquery-scrollbar/jquery.scrollbar.css" rel="stylesheet" type="text/css" />
		
		
		<link href="webarch/css/webarch.css" rel="stylesheet" type="text/css" />
		
	</head>
	
	
	<body class="error-body no-top lazy" data-original="assets/img/work.jpg" style="background-image: url('assets/img/work.jpg')">
		<div class="container">
			<div class="row login-container animated fadeInUp">
				<div class="col-md-7 col-md-offset-2 tiles white no-padding">
					<div class="p-t-30 p-l-40 p-b-20 xs-p-t-10 xs-p-l-10 xs-p-b-10">
						<div class="pull-left">
							<h2 class="normal">
								Sign in to Parahit CMS
							</h2>
							
							<p class="p-b-20">
								Sign up Now! for Parahit Content Management System 
							</p>
							
						</div>
						<div class="logo_img pull-right"> 
							<img src="assets/img/logo.png" width="160px">
						</div>
						
						
						
						
					</div>
					<div class="tiles grey p-t-20 p-b-20 no-margin text-black col-md-12">
						<div role="tabpanel" class="tab-pane active" id="tab_login">
							 <form name="loginform" class="animated fadeIn validate" method="post" action="">
                    <input type="hidden" name="logged" value="yes" />
                    <input type="hidden" name="back" value="<?php echo $_REQUEST['back']; ?>" />
					<?php if($_SESSION['sess_msg']){?>
                        
                            <div class="col-md-12 text-center color_red">
                                <?php echo $_SESSION['sess_msg'];$_SESSION['sess_msg']='';?>
                            </div>
                        <?php } ?>
								<div class="row form-row m-l-20 m-r-20 xs-m-l-10 xs-m-r-10">
									<div class="col-md-6 col-sm-6">
										<input class="form-control" id="login_username" name="login_username" placeholder="Username" type="email" required>
									</div>
									<div class="col-md-6 col-sm-6">
										<input class="form-control" id="login_pass" name="login_pass" placeholder="Password" type="password" required>
									</div>
								</div>
								<div class="row p-t-10 m-l-20 m-r-20 xs-m-l-10 xs-m-r-10">
									<div class="control-group col-md-10">
										<div class="checkbox checkbox check-success">
											<button class="btn btn-primary btn-cons " type="submit"> 
												<i class="material-icons">fingerprint
												</i> Authenticate Access
											</button>
										</div>
									</div>
								</div>
							</form>
						</div>
						
					</div>
				</div>
			</div>
		</div>
		
		<script src="assets/plugins/pace/pace.min.js" type="text/javascript"></script>
		<script src="assets/plugins/jquery/jquery-1.11.3.min.js" type="text/javascript"></script>
		<script src="assets/plugins/bootstrapv3/js/bootstrap.min.js" type="text/javascript"></script>
		<script src="assets/plugins/jquery-block-ui/jqueryblockui.min.js" type="text/javascript"></script>
		<script src="assets/plugins/jquery-unveil/jquery.unveil.min.js" type="text/javascript"></script>
		<script src="assets/plugins/jquery-scrollbar/jquery.scrollbar.min.js" type="text/javascript"></script>
		<script src="assets/plugins/jquery-numberAnimate/jquery.animateNumbers.js" type="text/javascript"></script>
		<script src="assets/plugins/jquery-validation/js/jquery.validate.min.js" type="text/javascript"></script>
		<script src="assets/plugins/bootstrap-select2/select2.min.js" type="text/javascript"></script>
		<script src="webarch/js/webarch.js" type="text/javascript"></script>
		<script src="assets/js/chat.js" type="text/javascript"></script>
		
	</body>
</html>								