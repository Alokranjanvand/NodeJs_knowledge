<?php
	session_start();
	include("include/config.php");
	include("include/functions.php"); 
	include("include/simpleimage.php");
	validate_admin();
	$username=$mysqli->real_escape_string($_POST["username"]);
	$email=$mysqli->real_escape_string($_POST["email"]);
	$mobile=$mysqli->real_escape_string($_POST["mobile"]);
	$pass=$mysqli->real_escape_string($_POST["password"]);
	$role_id=$mysqli->real_escape_string($_POST["role_id"]);
	$current_date=current_date();
	$password= EncryptPassword($pass);
	if($_REQUEST['submitForm']=='yes'){
		if($_REQUEST['id']==''){
			$q="insert into ".TBL_USER." set username ='$username',email='$email',mobile='$mobile',password='$password',role_id='$role_id',created_date='$current_date'";
			$mysqli->query($q);
			//echo $q;
			//die;
			$_SESSION['successfully']='User  added sucessfully';
			} else {
			$sql="update ".TBL_USER." set username ='$username',email='$email',mobile='$mobile',password='$password',role_id='$role_id',modified_date='$current_date'";
			$sql.=" where id=".$_REQUEST['id'];
			$mysqli->query($sql);
			$_SESSION['successfully']='User updated sucessfully';
		}
		header("location:view_user.php");
	}      
	if($_REQUEST['id']!=''){
		$sql=$mysqli->query("select * from ".TBL_USER." where id=".$_REQUEST['id']);
		$result=$sql->fetch_object();
	}
?>
<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
		<meta charset="utf-8" />
		<title><?php echo SITE_TITLE; ?></title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
		<meta content="" name="description" />
		<meta content="" name="author" />
		<script src="../../cdn-cgi/apps/head/QJpHOqznaMvNOv9CGoAdo_yvYKU.js"></script>
		<link href="assets/plugins/font-awesome/css/font-awesome.css" rel="stylesheet" type="text/css" />
		<link href="assets/plugins/bootstrap-select2/select2.css" rel="stylesheet" type="text/css" media="screen" />
		<link href="assets/plugins/bootstrap-datepicker/css/datepicker.css" rel="stylesheet" type="text/css" />
		<link href="assets/plugins/bootstrap-timepicker/css/bootstrap-timepicker.css" rel="stylesheet" type="text/css" />
		<link href="assets/plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.css" rel="stylesheet" type="text/css" />
		<link href="assets/plugins/boostrap-checkbox/css/bootstrap-checkbox.css" rel="stylesheet" type="text/css" media="screen" />
		<link rel="stylesheet" href="assets/plugins/ios-switch/ios7-switch.css" type="text/css" media="screen">
		<link href="assets/plugins/pace/pace-theme-flash.css" rel="stylesheet" type="text/css" media="screen" />
		<link href="assets/plugins/bootstrapv3/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
		<link href="assets/plugins/bootstrapv3/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css" />
		<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
		<link href="assets/plugins/animate.min.css" rel="stylesheet" type="text/css" />
		<link href="assets/plugins/jquery-scrollbar/jquery.scrollbar.css" rel="stylesheet" type="text/css" />
		<link href="webarch/css/webarch.css" rel="stylesheet" type="text/css" />
		
	</head>
	
	
	<body class="">
		
		<div class="header navbar navbar-inverse ">
			
			<div class="navbar-inner">
				
				<?php include('header.php');?>
				
				
				<div class="page-container row">
					<?php include('sidebar.php');?>
					
					
					
					
					<div class="page-content">
						
						
						<div id="portlet-config" class="modal hide">
							<div class="modal-header">
								<button data-dismiss="modal" class="close" type="button"></button>
								<h3>Widget Settings</h3>
							</div>
							<div class="modal-body"> Widget settings form goes here </div>
						</div>
						<div class="clearfix"></div>
						<div class="content">
							<ul class="breadcrumb">
								<li>
									<p>YOU ARE HERE</p>
								</li>
								<li><a href="#" class="active">Add User</a> </li>
							</ul>
							
							<div class="row">
								<div class="col-md-12">
									<div class="grid simple form-grid">
										<div class="grid-title no-border">
											<h4><span class="semi-bold">Add User Details</span></h4>
											<div class="tools">
												<a href="javascript:;" class="collapse"></a>
												<a href="javascript:;" class="reload" onclick="document.location.reload(true)"></a>
											</div>
										</div>
										<div class="grid-body no-border">
											
											<form name="Admin_form" method="POST" enctype="multipart/form-data" action="" autocomplete="off" class="validate">
												<input type="hidden" name="submitForm" value="yes" />
												<div class="form-group">
													<font color="green"><strong><?php echo $_SESSION['sess_msg']; $_SESSION['sess_msg']='';?></strong></font>
												</div>
												<div class="row column-seperation">
													<div class="col-md-12">
														<div class="row form-row">
															
															<div class="col-md-12">
																<span id="err" class="text-danger text-center"></span>
															</div>
															<div class="col-md-6">
																<input type="text" class="form-control" name="username" id="name" placeholder="User Name" value="<?php echo stripslashes($result->username);?>" >
															</div>
															
															<div class="col-md-6">
																<input type="text" class="form-control" name="email" id="email" placeholder="Email Id" value="<?php echo stripslashes($result->email);?>">
															</div>
															
															<div class="col-md-6">
																<input type="text" class="form-control" name="mobile" id="mobile" placeholder="Mobile Number" value="<?php echo stripslashes($result->mobile);?>">
															</div>
															<div class="col-md-6">
																<input type="password" class="form-control" name="password" id="password" placeholder="Password" value="">
															</div>
															<div class="col-md-6">
																<input type="password" class="form-control" id="confirm_password" placeholder="Confirm Password" name="Conf_pass" value="">
															</div>
															<div class="col-md-6">
																<div class="form-group" id="role_id">
																	<div class=" right">
																		<i class=""></i>
																		<select class="form-control select2"  name="role_id" data-init-plugin="select2" required>
																			<option value="">Select Role Type</option>
																			<option value="1"<?php if($result->role_id=='1') { ?>selected<?php } ?>>Super Admin</option>
																			<option value="2"<?php if($result->role_id=='2') { ?>selected<?php } ?>>Editor</option>
																			
																		</select>
																	</div>
																</div>
															</div>
															<div class="col-md-6">
																<button class="btn btn-white btn-cons pull-right" type="reset">Cancel</button>
																<button class="btn btn-success btn-cons pull-right" type="button" onclick="return User_Validation();"><i class="icon-ok"></i> Add</button>
																
															</div>
														</div>
														
														
													</div>
													
												</div>
												
											</form>
										</div>
									</div>
								</div>
							</div>
							<!---row--->
						</div>
					</div>
					<script data-cfasync="false" src="../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="assets/plugins/pace/pace.min.js" type="text/javascript"></script>
					
					<script src="assets/plugins/jquery/jquery-1.11.3.min.js" type="text/javascript"></script>
					<script src="assets/plugins/bootstrapv3/js/bootstrap.min.js" type="text/javascript"></script>
					<script src="assets/plugins/jquery-block-ui/jqueryblockui.min.js" type="text/javascript"></script>
					<script src="assets/plugins/jquery-unveil/jquery.unveil.min.js" type="text/javascript"></script>
					<script src="assets/plugins/jquery-scrollbar/jquery.scrollbar.min.js" type="text/javascript"></script>
					<script src="assets/plugins/jquery-numberAnimate/jquery.animateNumbers.js" type="text/javascript"></script>
					<script src="assets/plugins/jquery-validation/js/jquery.validate.min.js" type="text/javascript"></script>
					<script src="assets/plugins/bootstrap-select2/select2.min.js" type="text/javascript"></script>
					
					
					<script src="webarch/js/webarch.js" type="text/javascript"></script>
					<script src="assets/js/chat.js" type="text/javascript"></script>
					
					
					<script src="assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
					<script src="assets/plugins/boostrap-form-wizard/js/jquery.bootstrap.wizard.min.js" type="text/javascript"></script>
					
					<script src="assets/js/form_validations.js" type="text/javascript"></script>
					<script type="text/javascript" src="include/ckeditor/ckeditor.js"></script>
					<script>
						
						function User_Validation()
						{
						//alert('hello');
						var Name = /^([a-zA-Z ])+$/;
						var err = "";
						var Numeric =/^([0-9\-\+])+$/;
						var filter  = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
						if(document.Admin_form.name.value==false)
						{
						document.getElementById("name").style.border="1px solid red";
						document.getElementById("err").innerHTML = 'Please Enter  User Name';
						document.Admin_form.name.focus();
						return false;
						}
						else if (!Name.test(document.Admin_form.name.value))
						{
						document.getElementById("name").style.border="1px solid red";
						document.Admin_form.name.focus();
						document.getElementById("err").innerHTML="Name can contain characters only.";
						return false;
						}
						else
						{
						document.getElementById("name").style.border="1px solid green";
						document.getElementById("err").innerHTML = '';
						}
						if(document.Admin_form.email.value==false)
						{
						document.getElementById("email").style.border="1px solid red";
						document.getElementById("err").innerHTML = 'Please enter your email';
						document.Admin_form.email.focus();
						return false;
						}
						else if(!filter.test(document.Admin_form.email.value))
						{
						document.getElementById("email").style.border="1px solid red";
						document.getElementById("err").innerHTML = 'Please enter a valid email';
						document.Admin_form.email.focus();
						return false;
						}
						else
						{
						document.getElementById("email").style.border="1px solid  green";
						document.getElementById("err").innerHTML = '';
						}
						if(document.Admin_form.mobile.value==false)
						{
						document.getElementById("mobile").style.border="1px solid red";
						document.getElementById("err").innerHTML = 'Please enter your  mobile no.';
						document.Admin_form.mobile.focus();
						return false;
						}
						else if (!Numeric.test(document.Admin_form.mobile.value))
						{
						document.getElementById("mobile").style.border="1px solid red";
						document.Admin_form.mobile.focus();
						document.getElementById("err").innerHTML="Mobile number must contain only digits and should have 10 digits."+lent;
						return false;
						}
						else if (document.Admin_form.mobile.value.length < 10 || document.Admin_form.mobile.value.length > 11)
						{
						document.getElementById("mobile").style.border="1px solid red";
						document.Admin_form.mobile.focus();
						document.getElementById("err").innerHTML="Mobile number must contain only digits and should have 10 digits.";
						return false;
						}
						else
						{
						document.getElementById("mobile").style.border="1px solid  green";
						document.getElementById("err").innerHTML = '';
						}
						if(document.Admin_form.password.value==false)
						{
						document.getElementById("password").style.border="1px solid red";
						document.getElementById("err").innerHTML = 'Password can not be blank ';
						document.Admin_form.password.focus();
						return false;
						}
						else if(document.Admin_form.password.value.length < 8 || document.Admin_form.password.value.length > 20 )
						{
						document.getElementById("password").style.border="1px solid red";
						document.getElementById("err").innerHTML = 'Password must  be 8-20 character only ';
						document.Admin_form.password.focus();
						return false;
						}
						else
						{
						document.getElementById("password").style.border="1px solid  green";
						document.getElementById("err").innerHTML = '';
						} 
						if(document.Admin_form.confirm_password.value==false)
						{
						document.getElementById("confirm_password").style.border="1px solid red";
						document.getElementById("err").innerHTML = 'Password can not be blanck ';
						document.Admin_form.confirm_password.focus();
						return false;
						}
						else if(document.Admin_form.password.value != document.Admin_form.confirm_password.value )
						{
						document.getElementById("confirm_password").style.border="1px solid red";
						document.getElementById("err").innerHTML = 'Password &  Confirm Password does not match ';
						document.Admin_form.confirm_password.focus();
						return false;
						}
						else
						{
						document.getElementById("confirm_password").style.border="1px solid  green";
						document.getElementById("err").innerHTML = '';
						}
						if(document.Admin_form.role_id.value==false)
						{
						document.getElementById("role_id").style.border="1px solid red";
						document.getElementById("err").innerHTML = 'Select Role';
						document.Admin_form.password.focus();
						return false;
						}
						else
						{
						document.getElementById("role_id").style.border="1px solid  green";
						document.getElementById("err").innerHTML = '';
						}
						document.Admin_form.submit();
						}
					</script>
					
				</body>
			</body>
		</html>																																																			