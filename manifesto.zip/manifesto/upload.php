<?php 
	include('include/config.php');
	include('include/functions.php');
	validate_admin();
	/* Getting file name */
	$filename=time().$_FILES['file']['name'];
 $fileinfo = @getimagesize($_FILES["file"]["tmp_name"]);
    $width = $fileinfo[0];
    $height = $fileinfo[1];
	error_log("withddd= ".$width);
	error_log("height= ".$height);
	
	/* Location */
	$location = "gallery/".$filename;
	$uploadOk = 1;
	$imageFileType = pathinfo($location,PATHINFO_EXTENSION);
	
	/* Valid Extensions */
	$valid_extensions = array("jpg","jpeg","png","gif","tiff","webp","tif","bmp","svg");
	/* Check file extension */
	if( !in_array(strtolower($imageFileType),$valid_extensions) ) {
		$uploadOk = 0;
	}
	
	if($uploadOk == 0){
		echo "File Not Uploaded";
		}else{
		/* Upload file */
		if(move_uploaded_file($_FILES['file']['tmp_name'],$location)){
			
			$user_id=$_SESSION['sess_admin_id'];
			$q="insert into tbl_gallery set user_id='$user_id',width='$width',height='$height',gallery='$filename',created_date=now()";
			$upload=$mysqli->query($q);
			if($upload){
				//echo "File Uploaded Successfully...!";
			}
			
			
			}else{
			echo "File Not Uploaded";
		}
	}
?>
<div class="gjs-am-asset gjs-am-asset-image gjs-am-highlight">
      <div class="gjs-am-preview-cont">
        
      <div class="gjs-am-preview"  style="background-image: url('<?php echo $location;?>');"></div>
      <div class="gjs-am-preview-bg gjs-checker-bg"></div>
    
      </div>
      <div class="gjs-am-meta">
        
      <div class="gjs-am-name"><?php echo $filename;?></div>
      <div class="gjs-am-dimensions"><?php echo $width;?>x<?php echo $height;?>px</div>
    
      </div>
      <div class="gjs-am-close" data-toggle="asset-remove">
        x
      </div>
    </div>