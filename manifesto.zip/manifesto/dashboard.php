<?php
include("include/config.php");
include("include/functions.php");
validate_admin();
?>
<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
		<meta charset="utf-8" />
		<title><?php echo SITE_TITLE; ?></title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
		<meta content="" name="description" />
		<meta content="" name="author" />
		<script src="../../cdn-cgi/apps/head/QJpHOqznaMvNOv9CGoAdo_yvYKU.js"></script><link href="assets/plugins/font-awesome/css/font-awesome.css" rel="stylesheet" type="text/css" />
		<link href="assets/plugins/gritter/css/jquery.gritter.css" rel="stylesheet" type="text/css" />
		<link href="assets/plugins/bootstrap-datepicker/css/datepicker.css" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="assets/plugins/jquery-ricksaw-chart/css/rickshaw.css" type="text/css" media="screen">
		<link rel="stylesheet" href="assets/plugins/jquery-morris-chart/css/morris.css" type="text/css" media="screen">
		<link href="assets/plugins/bootstrap-select2/select2.css" rel="stylesheet" type="text/css" media="screen" />
		<link href="assets/plugins/jquery-jvectormap/css/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" media="screen" />
		<link href="assets/plugins/pace/pace-theme-flash.css" rel="stylesheet" type="text/css" media="screen" />
		<link href="assets/plugins/bootstrapv3/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
		<link href="assets/plugins/bootstrapv3/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css" />
		<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
		<link href="assets/plugins/animate.min.css" rel="stylesheet" type="text/css" />
		<link href="assets/plugins/jquery-scrollbar/jquery.scrollbar.css" rel="stylesheet" type="text/css" />
		
		
		<link href="webarch/css/webarch.css" rel="stylesheet" type="text/css" />
		
	</head>
	
	
	<body class="">
		
		<div class="header navbar navbar-inverse ">
			
			<div class="navbar-inner">
				
				<?php include('header.php');?>
		
		
		<div class="page-container row">
			<?php include('sidebar.php');?>
			
			
			
			
			<div class="page-content">
				
				<div id="portlet-config" class="modal hide">
					<div class="modal-header">
						<button data-dismiss="modal" class="close" type="button"></button>
						<h3>Widget Settings</h3>
					</div>
					<div class="modal-body"> Widget settings form goes here </div>
				</div>
				<div class="clearfix"></div>
				<div class="content ">
					<div class="page-title">
						<h3>Dashboard </h3>
					</div>
					<div id="container">
						<div class="row 2col">
							<div class="col-md-4 col-sm-6 spacing-bottom-sm spacing-bottom">
								<div class="tiles blue added-margin">
									<div class="tiles-body">
										<div class="controller">
											<a href="javascript:;" class="reload"></a>
											<a href="javascript:;" class="remove"></a>
										</div>
										<div class="tiles-title"> Total Website </div>
										<div class="heading"> <span class="animate-number" data-value="1" data-animation-duration="1200">1</span></div>
										
									</div>
								</div>
							</div>
							<div class="col-md-4 col-sm-6 spacing-bottom-sm spacing-bottom">
								<div class="tiles green added-margin">
									<div class="tiles-body">
										<div class="controller">
											<a href="javascript:;" class="reload"></a>
											<a href="javascript:;" class="remove"></a>
										</div>
										<div class="tiles-title"> Total User </div>
										<div class="heading"> <span class="animate-number" data-value="<?php echo getUser();?>" data-animation-duration="1000">0</span> </div>
										<!--<div class="progress transparent progress-small no-radius">
											<div class="progress-bar progress-bar-white animate-progress-bar" data-percentage="79%"></div>
										</div>
										<div class="description"><i class="icon-custom-up"></i><span class="text-white mini-description ">&nbsp; 2% higher <span class="blend">than last month</span></span>
										</div>-->
									</div>
								</div>
							</div>
							<div class="col-md-4 col-sm-6 spacing-bottom">
								<div class="tiles red added-margin">
									<div class="tiles-body">
										<div class="controller">
											<a href="javascript:;" class="reload"></a>
											<a href="javascript:;" class="remove"></a>
										</div>
										<div class="tiles-title"> TODAY’S <?php echo date("l");?> </div>
										<div class="heading"> <span class="animate-number" data-value="0" data-animation-duration="1200"><?php echo date("l");?></span> </div>
										<!--<div class="progress transparent progress-white progress-small no-radius">
											<div class="progress-bar progress-bar-white animate-progress-bar" data-percentage="45%"></div>
										</div>
										<div class="description"><i class="icon-custom-up"></i><span class="text-white mini-description ">&nbsp; 5% higher <span class="blend">than last month</span></span>
										</div>-->
									</div>
								</div>
							</div>
							<!--
							<div class="col-md-3 col-sm-6">
								<div class="tiles purple added-margin">
									<div class="tiles-body">
										<div class="controller">
											<a href="javascript:;" class="reload"></a>
											<a href="javascript:;" class="remove"></a>
										</div>
										<div class="tiles-title"> TODAY’S FEEDBACKS </div>
										<div class="row-fluid">
											<div class="heading"> <span class="animate-number" data-value="1600" data-animation-duration="700">0</span> </div>
											<div class="progress transparent progress-white progress-small no-radius">
												<div class="progress-bar progress-bar-white animate-progress-bar" data-percentage="12%"></div>
											</div>
										</div>
										<div class="description"><i class="icon-custom-up"></i><span class="text-white mini-description ">&nbsp; 3% higher <span class="blend">than last month</span></span>
										</div>
									</div>
								</div>
							</div>
						</div>
						-->
						
						
					</div>
				</div>
				<script src="assets/plugins/pace/pace.min.js" type="text/javascript"></script>
				<script src="assets/plugins/jquery/jquery-1.11.3.min.js" type="text/javascript"></script>
				<script src="assets/plugins/bootstrapv3/js/bootstrap.min.js" type="text/javascript"></script>
				<script src="assets/plugins/jquery-block-ui/jqueryblockui.min.js" type="text/javascript"></script>
				<script src="assets/plugins/jquery-unveil/jquery.unveil.min.js" type="text/javascript"></script>
				<script src="assets/plugins/jquery-scrollbar/jquery.scrollbar.min.js" type="text/javascript"></script>
				<script src="assets/plugins/jquery-numberAnimate/jquery.animateNumbers.js" type="text/javascript"></script>
				<script src="assets/plugins/jquery-validation/js/jquery.validate.min.js" type="text/javascript"></script>
				<script src="assets/plugins/bootstrap-select2/select2.min.js" type="text/javascript"></script>
				<script src="webarch/js/webarch.js" type="text/javascript"></script>
				<script src="assets/plugins/jquery-ui/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
				<script src="assets/plugins/jquery-easy-pie-chart/js/jquery.easypiechart.min.js"></script>
				<script src="assets/plugins/jquery-slider/jquery.sidr.min.js" type="text/javascript"></script>
				<script src="assets/plugins/jquery-jvectormap/js/jquery-jvectormap-1.2.2.min.js" type="text/javascript"></script>
				<script src="assets/plugins/jquery-jvectormap/js/jquery-jvectormap-us-lcc-en.js" type="text/javascript"></script>
				<script src="assets/plugins/jquery-sparkline/jquery-sparkline.js"></script>
				<script src="assets/plugins/jquery-flot/jquery.flot.min.js"></script>
				<script src="assets/plugins/jquery-flot/jquery.flot.animator.min.js"></script>
				<script src="assets/plugins/skycons/skycons.js"></script>
				<script src="assets/js/dashboard.js" type="text/javascript"></script>
			</body>
		</html>								