<?php session_start();
include("include/config.php");
include("include/functions.php"); 
validate_admin();
$arr =$_POST['ids'];
//print_r($_REQUEST);
$number = count($arr); 

$Submit =$_POST['what'];

if(count($arr)>0){
	$str_rest_refs=implode(",",$arr);
	if($Submit=='Delete')
	{	  
	$eventimage=$mysqli->query("select event_image,event_image_thumbnail from event where event_id in ($str_rest_refs) "); 
		while($resulteventImage=$eventimage->fetch_object()){
			$str3=$resulteventImage->event_image;
			$str4=$resulteventImage->event_image_thumbnail;
			$url3=trim($str3,SITE_URL);
			$url4=trim($str4,SITE_URL);
			@unlink("../".$url3);
			@unlink("../".$url4);		
		}
	  $imageArr=$mysqli->query("select content_media.media_url,content_media.media_thumbnail,content.* from content LEFT JOIN" 
	  ."content_media ON content.content_id = content_media.content_id where content.event_id in ($str_rest_refs)"); 
		while($resultImage=$imageArr->fetch_object()){
			$str=$resultImage->media_url;
			if ( preg_match("/.mp4/", $str)){ 
				$url3=trim($str,SITE_URL);
				$url=$url3.".mp4" ;
				
			}
			else{
				$url=trim($str,SITE_URL);
			}
			$str2=$resultImage->media_thumbnail;
			error_log('str2= '.$str2);
			error_log('url= '.$url);
			$url2=trim($str2,SITE_URL);
			error_log('url2= '.$url2);
			@unlink("../".$url);
			@unlink("../".$url2);		
		}
	    $sql="delete from event where event_id in ($str_rest_refs)"; 
		$mysqli->query($sql);
		$sql2="DELETE content, content_media FROM content LEFT JOIN content_media ON content.content_id = content_media.content_id
where content.event_id in ($str_rest_refs) "; 
		$mysqli->query($sql2);
		$sess_msg='Selected record ('.$number.') deleted successfully';
		$_SESSION['sess_msg']=$sess_msg;
    }
	elseif($Submit=='Approved')
	{	
		$sql="update event set is_approve=2 where event_id in ($str_rest_refs)";
		$mysqli->query($sql);
		$sess_msg='Selected record ('.$number.') Approved successfully';
		$_SESSION['sess_msg']=$sess_msg;
	}
	elseif($Submit=='Reject')
	{	
		$sql="update event set is_approve=0 where event_id in ($str_rest_refs)";
		$mysqli->query($sql);
		$sess_msg='Selected record ('.$number.') Reject successfully';
		$_SESSION['sess_msg']=$sess_msg;
	}
	elseif($Submit=='Pending')
	{		
		 $sql="update event set is_approve=1 where event_id in ($str_rest_refs)";
		$mysqli->query($sql);
		$sess_msg='Selected record ('.$number.') Pending successfully';
		$_SESSION['sess_msg']=$sess_msg;
	}
		
	}
	
else{
	$sess_msg="Please select check box";
	$_SESSION['sess_msg']=$sess_msg;
	header("location: ".$_SERVER['HTTP_REFERER']);
	exit();
	}
	header("location: ".$_SERVER['HTTP_REFERER']);
	exit();
	
?>
