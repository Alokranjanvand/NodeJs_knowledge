<div class="header-seperation">
					<ul class="nav pull-left notifcation-center visible-xs visible-sm">
						<li class="dropdown">
							<a href="#main-menu" data-webarch="toggle-left-side">
								<i class="material-icons">menu</i>
							</a>
						</li>
					</ul>
					
					<a href="index.html">
						<img src="assets/img/logo.png" class="logo" alt="" data-src="assets/img/logo.png" data-src-retina="assets/img/logo2x.png" width="106" height="21" />
					</a>
					
					<ul class="nav pull-right notifcation-center">
						<li class="dropdown hidden-xs hidden-sm">
							<a href="index.html" class="dropdown-toggle active">
								<i class="material-icons">home</i>
							</a>
						</li>
					</ul>
				</div>
				<div class="header-quick-nav">
					
					<div class="pull-left">
						<ul class="nav quick-section">
							<li class="quicklinks">
								<a href="#" class="" id="layout-condensed-toggle">
									<i class="material-icons">menu</i>
								</a>
							</li>
						</ul>
						<ul class="nav quick-section">
                    <!-- <li class="quicklinks  m-r-10">
                        <a href="#" class="">
                        <i class="material-icons">refresh</i>
                        </a>
                     </li> -->
					  <li class="quicklinks"> <span class="h-seperate"></span></li>
                     <li class="quicklinks">
                        <a href="logout.php" class="">
                        <i class="material-icons">fingerprint</i> 					
                        </a>
                     </li>
					 
					  <li class="quicklinks" style="padding-top:6px;"> Welcome <?php echo ucfirst($_SESSION['sess_admin_username']);?></li>
					  
						<li class="quicklinks"> <span class="h-seperate"></span></li>
						
               
                    
                  </ul>
					</div>
					<div id="notification-list" style="display:none">
						<div style="width:300px">
							<div class="notification-messages info">
								<div class="user-profile">
									<img src="assets/img/profiles/d.jpg" alt="" data-src="assets/img/profiles/d.jpg" data-src-retina="assets/img/profiles/d2x.jpg" width="35" height="35">
								</div>
								<div class="message-wrapper">
									<div class="heading">
										David Nester - Commented on your wall
									</div>
									<div class="description">
										Meeting postponed to tomorrow
									</div>
									<div class="date pull-left">
										A min ago
									</div>
								</div>
								<div class="clearfix"></div>
							</div>
							<div class="notification-messages danger">
								<div class="iconholder">
									<i class="icon-warning-sign"></i>
								</div>
								<div class="message-wrapper">
									<div class="heading">
										Server load limited
									</div>
									<div class="description">
										Database server has reached its daily capicity
									</div>
									<div class="date pull-left">
										2 mins ago
									</div>
								</div>
								<div class="clearfix"></div>
							</div>
							<div class="notification-messages success">
								<div class="user-profile">
									<img src="assets/img/profiles/h.jpg" alt="" data-src="assets/img/profiles/h.jpg" data-src-retina="assets/img/profiles/h2x.jpg" width="35" height="35">
								</div>
								<div class="message-wrapper">
									<div class="heading">
										You haveve got 150 messages
									</div>
									<div class="description">
										150 newly unread messages in your inbox
									</div>
									<div class="date pull-left">
										An hour ago
									</div>
								</div>
								<div class="clearfix"></div>
							</div>
						</div>
					</div>
					
					
					
				</div>
				
			</div>
			
</div>