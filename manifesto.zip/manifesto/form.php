<?php
	include("include/config.php");
	include("include/functions.php");
	validate_admin();
?>
<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
		<meta charset="utf-8" />
		<title><?php echo SITE_TITLE; ?></title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
		<meta content="" name="description" />
		<meta content="" name="author" />
		<script src="../../cdn-cgi/apps/head/QJpHOqznaMvNOv9CGoAdo_yvYKU.js"></script>
		<link href="assets/plugins/font-awesome/css/font-awesome.css" rel="stylesheet" type="text/css" />
		<link href="assets/plugins/bootstrap-select2/select2.css" rel="stylesheet" type="text/css" media="screen" />
		<link href="assets/plugins/bootstrap-datepicker/css/datepicker.css" rel="stylesheet" type="text/css" />
		<link href="assets/plugins/bootstrap-timepicker/css/bootstrap-timepicker.css" rel="stylesheet" type="text/css" />
		<link href="assets/plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.css" rel="stylesheet" type="text/css" />
		<link href="assets/plugins/boostrap-checkbox/css/bootstrap-checkbox.css" rel="stylesheet" type="text/css" media="screen" />
		<link rel="stylesheet" href="assets/plugins/ios-switch/ios7-switch.css" type="text/css" media="screen">
		<link href="assets/plugins/pace/pace-theme-flash.css" rel="stylesheet" type="text/css" media="screen" />
		<link href="assets/plugins/bootstrapv3/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
		<link href="assets/plugins/bootstrapv3/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css" />
		<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
		<link href="assets/plugins/animate.min.css" rel="stylesheet" type="text/css" />
		<link href="assets/plugins/jquery-scrollbar/jquery.scrollbar.css" rel="stylesheet" type="text/css" />
		<link href="webarch/css/webarch.css" rel="stylesheet" type="text/css" />
	</head>
	
	
	<body class="">
		
		<div class="header navbar navbar-inverse ">
			
			<div class="navbar-inner">
				
				<?php include('header.php');?>
				
				
				<div class="page-container row">
					<?php include('sidebar.php');?>
					
					
					
					
					<div class="page-content">
						
						
						<div id="portlet-config" class="modal hide">
							<div class="modal-header">
								<button data-dismiss="modal" class="close" type="button"></button>
								<h3>Widget Settings</h3>
							</div>
							<div class="modal-body"> Widget settings form goes here </div>
						</div>
						<div class="clearfix"></div>
						<div class="content">
							<ul class="breadcrumb">
								<li>
									<p>YOU ARE HERE</p>
								</li>
								<li><a href="#" class="active">Form layouts & Validations</a> </li>
							</ul>
							<div class="page-title"> <i class="icon-custom-left"></i>
								<h3>Form - <span class="semi-bold">Validations</span></h3>
							</div>
							<div class="row">
								<div class="col-md-6">
									<div class="grid simple form-grid">
										<div class="grid-title no-border">
											<h4>Traditional <span class="semi-bold">Validation</span></h4>
											<div class="tools">
												<a href="javascript:;" class="collapse"></a>
												<a href="#grid-config" data-toggle="modal" class="config"></a>
												<a href="javascript:;" class="reload"></a>
												<a href="javascript:;" class="remove"></a>
											</div>
										</div>
										<div class="grid-body no-border">
											<form action="#" id="form_traditional_validation" name="form_traditional_validation" role="form" autocomplete="off" class="validate">
												<div class="form-group">
													<label class="form-label">Amount</label> <span class="help">e.g. "5000"</span>
													<input class="form-control" id="form1Amount" name="form1Amount" type="number" required>
												</div>
												<div class="form-group">
													<label class="form-label">Card Holder's Name</label> <span class="help">e.g. "Jane Smith"</span>
													<div class="input-with-icon right">
														<i class=""></i>
														<input class="form-control" id="form1CardHolderName" name="form1CardHolderName" type="text" required>
													</div>
												</div>
												<div class="form-group">
													<label class="form-label">Card Number</label>z <span class="help">e.g. "5689569985"</span>
													<div class="input-with-icon right">
														<input class="form-control" id="form1CardNumber" name="form1CardNumber" type="text" type=text pattern="[0-9]{13,16}" required>
													</div>
												</div>
												<div class="form-group">
													<label class="form-label">Card Type</label> <span class="help">e.g. "Visa"</span>
													<div class=" right">
														<i class=""></i>
														<select class="form-control select2" id="cardType" name="cardType" data-init-plugin="select2" required>
															<option value="">
																Select Type
															</option>
															<option value="1">
																Visa
															</option>
															<option value="2">
																Master
															</option>
														</select>
													</div>
												</div>
												<div class="form-actions">
													<div class="pull-right">
														<button class="btn btn-success btn-cons" type="submit"><i class="icon-ok"></i> Save</button>
														<button class="btn btn-white btn-cons" type="button">Cancel</button>
													</div>
												</div>
											</form>
										</div>
									</div>
								</div>
								<div class="col-md-6">
									<div class="grid simple form-grid">
										<div class="grid-title no-border">
											<h4>Icon <span class="semi-bold">Validation</span></h4>
											<div class="tools">
												<a href="javascript:;" class="collapse"></a>
												<a href="#grid-config" data-toggle="modal" class="config"></a>
												<a href="javascript:;" class="reload"></a>
												<a href="javascript:;" class="remove"></a>
											</div>
										</div>
										<div class="grid-body no-border">
											<br>
											<form id="form_iconic_validation" action="#">
												<div class="form-group">
													<label class="form-label">Your Name</label>
													<span class="help">e.g. "Jonh Smith"</span>
													<div class="input-with-icon  right">
														<i class=""></i>
														<input type="text" name="form1Name" id="form1Name" class="form-control">
													</div>
												</div>
												<div class="form-group">
													<label class="form-label">Your email</label>
													<span class="help">e.g. "<a href="http://webarch.revox.io/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="a8c2c7c0c6e8cdd0c9c5d886cbc7c5">[email&#160;protected]</a>"</span>
													<div class="input-with-icon  right">
														<i class=""></i>
														<input type="text" name="form1Email" id="form1Email" class="form-control">
													</div>
												</div>
												<div class="form-group">
													<label class="form-label">Website</label>
													<span class="help">e.g. "http://www.webarc.com"</span>
													<div class="input-with-icon  right">
														<i class=""></i>
														<input type="text" name="form1Url" id="form1Url" class="form-control">
													</div>
												</div>
												<div class="form-group">
													<label class="form-label">Gender</label>
													<span class="help">e.g. "Select one"</span>
													<div class="input-with-icon  right">
														<i class=""></i>
														<select name="gendericonic" id="gendericonic" class="select2 form-control" data-init-plugin="select2">
															<option value="">Select...</option>
															<option value="1">Male</option>
															<option value="2">Female</option>
														</select>
													</div>
												</div>
												<div class="form-actions">
													<div class="pull-right">
														<button type="submit" class="btn btn-danger btn-cons"><i class="icon-ok"></i> Save</button>
														<button type="button" class="btn btn-white btn-cons">Cancel</button>
													</div>
												</div>
											</form>
										</div>
									</div>
								</div>
							</div>
							<!---row--->
						</div>
					</div>
					<script data-cfasync="false" src="../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="assets/plugins/pace/pace.min.js" type="text/javascript"></script>
					
					<script src="assets/plugins/jquery/jquery-1.11.3.min.js" type="text/javascript"></script>
					<script src="assets/plugins/bootstrapv3/js/bootstrap.min.js" type="text/javascript"></script>
					<script src="assets/plugins/jquery-block-ui/jqueryblockui.min.js" type="text/javascript"></script>
					<script src="assets/plugins/jquery-unveil/jquery.unveil.min.js" type="text/javascript"></script>
					<script src="assets/plugins/jquery-scrollbar/jquery.scrollbar.min.js" type="text/javascript"></script>
					<script src="assets/plugins/jquery-numberAnimate/jquery.animateNumbers.js" type="text/javascript"></script>
					<script src="assets/plugins/jquery-validation/js/jquery.validate.min.js" type="text/javascript"></script>
					<script src="assets/plugins/bootstrap-select2/select2.min.js" type="text/javascript"></script>
					
					
					<script src="webarch/js/webarch.js" type="text/javascript"></script>
					<script src="assets/js/chat.js" type="text/javascript"></script>
					
					
					<script src="assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
					<script src="assets/plugins/boostrap-form-wizard/js/jquery.bootstrap.wizard.min.js" type="text/javascript"></script>
					
					<script src="assets/js/form_validations.js" type="text/javascript"></script>
					
					</body>
				</body>
			</html>																					