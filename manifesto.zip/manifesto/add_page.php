<?php
	session_start();
	include("include/config.php");
	include("include/functions.php"); 
	include("include/simpleimage.php");
	validate_admin();
	$title=$mysqli->real_escape_string($_POST["title"]);
	$slug=$mysqli->real_escape_string($_POST["slug"]);
	$body=trim($mysqli->real_escape_string($_POST["body"]));
	$user_id=$mysqli->real_escape_string($_POST["user_id"]);
	$status=$mysqli->real_escape_string($_POST["status"]);
	$current_date=current_date();
	$meta_description=trim($mysqli->real_escape_string($_POST["meta_description"]));
	if($_REQUEST['submitForm']=='yes'){
		$Image=new SimpleImage();
		if($_FILES['featured_images']['size']>0 && $_FILES['featured_images']['error']==''){
			$img=uniqid().$_FILES['featured_images']['name'];
			move_uploaded_file($_FILES['featured_images']['tmp_name'],"uploads/pages/".$img);
			$destination="uploads/pages/".$img;
		}
		if($_REQUEST['id']==''){
			$q="insert into ".TBL_PAGES." set user_id ='$user_id',title='$title',slug='$slug',body='$body',meta_description='$meta_description',featured_images='$img',created_date='$current_date',status='$status'";
			$mysqli->query($q);
			$_SESSION['successfully']='User  added sucessfully';
			
			} else {
			$sql="update ".TBL_PAGES." set user_id ='$user_id',title='$title',slug='$slug',body='$body',meta_description='$meta_description',modified_date='$current_date',status='$status'";
			$query=$mysqli->query("select * from ".TBL_PAGES." where id=".$_REQUEST['id']);
			if($img){
				$resultImage=$query->fetch_object();
				@unlink("uploads/pages/".$resultImage->featured_images);
				$sql.=",featured_images='$img' ";
			}			
			$sql.=" where id=".$_REQUEST['id'];
			//echo $sql;
			//die;
			$mysqli->query($sql);
			$_SESSION['successfully']='User updated sucessfully';
		}
		header("location:view_pages.php");
	}      
	if($_REQUEST['id']!=''){
		$sql=$mysqli->query("select * from ".TBL_PAGES." where id=".$_REQUEST['id']);
		$result=$sql->fetch_object();
	}
?>
<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
		<meta charset="utf-8" />
		<title><?php echo SITE_TITLE; ?></title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
		<meta content="" name="description" />
		<meta content="" name="author" />
		<script src="../../cdn-cgi/apps/head/QJpHOqznaMvNOv9CGoAdo_yvYKU.js"></script>
		<link href="assets/plugins/font-awesome/css/font-awesome.css" rel="stylesheet" type="text/css" />
		<link href="assets/plugins/bootstrap-select2/select2.css" rel="stylesheet" type="text/css" media="screen" />
		<link href="assets/plugins/bootstrap-datepicker/css/datepicker.css" rel="stylesheet" type="text/css" />
		<link href="assets/plugins/bootstrap-timepicker/css/bootstrap-timepicker.css" rel="stylesheet" type="text/css" />
		<link href="assets/plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.css" rel="stylesheet" type="text/css" />
		<link href="assets/plugins/boostrap-checkbox/css/bootstrap-checkbox.css" rel="stylesheet" type="text/css" media="screen" />
		<link rel="stylesheet" href="assets/plugins/ios-switch/ios7-switch.css" type="text/css" media="screen">
		<link href="assets/plugins/pace/pace-theme-flash.css" rel="stylesheet" type="text/css" media="screen" />
		<link href="assets/plugins/bootstrapv3/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
		<link href="assets/plugins/bootstrapv3/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css" />
		<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
		<link href="assets/plugins/animate.min.css" rel="stylesheet" type="text/css" />
		<link href="assets/plugins/jquery-scrollbar/jquery.scrollbar.css" rel="stylesheet" type="text/css" />
		<link href="webarch/css/webarch.css" rel="stylesheet" type="text/css" />
		
	</head>
	
	
	<body class="">
		
		<div class="header navbar navbar-inverse ">
			
			<div class="navbar-inner">
				
				<?php include('header.php');?>
				
				
				<div class="page-container row">
					<?php include('sidebar.php');?>
					
					
					
					
					<div class="page-content">
						
						
						<div id="portlet-config" class="modal hide">
							<div class="modal-header">
								<button data-dismiss="modal" class="close" type="button"></button>
								<h3>Widget Settings</h3>
							</div>
							<div class="modal-body"> Widget settings form goes here </div>
						</div>
						<div class="clearfix"></div>
						<div class="content">
							<ul class="breadcrumb">
								<li>
									<p>YOU ARE HERE</p>
								</li>
								<li><a href="#" class="active">Add Page</a> </li>
							</ul>
							<div class="page-title"> <i class="icon-custom-left"></i>
								<h3>Add - <span class="semi-bold">Page for publish</span></h3>
							</div>
							<div class="row">
								<div class="col-md-12">
									<div class="grid simple form-grid">
										<div class="grid-title no-border">
											<h4>Insert  <span class="semi-bold">Page</span></h4>
											<div class="tools">
												<a href="view_pages.php"><i class="fa fa-eye" aria-hidden="true"></i></a>
												<a href="javascript:;" class="collapse"></a>
												<a href="javascript:;" class="reload"></a>
											</div>
										</div>
										<div class="grid-body no-border">
											<form name="frm" method="POST" enctype="multipart/form-data" action="" autocomplete="off" class="validate">
												<input type="hidden" name="submitForm" value="yes" />
												<input type="hidden" name="user_id" value="<?php echo $_SESSION['sess_admin_id'];?>" />
												<div class="form-group">
													
													<font color="green"><strong><?php echo $_SESSION['sess_msg']; $_SESSION['sess_msg']='';?></strong></font>
													
												</div>
												<div class="form-group">
													<label class="form-label">Title </label>
													<input class="form-control" id="form1Amount" name="title" type="text" value="<?php echo stripslashes($result->title);?>" required>
												</div>
												<div class="form-group">
													<label class="form-label">Slug  </label>
													<input class="form-control" id="form1Amount" name="slug" type="text" value="<?php echo stripslashes($result->slug);?>" required>
												</div>
												<div class="form-group">
													<label class="form-label">Body  </label>
													<textarea name="body" class="ckeditor admintextarea" rows="8" cols="30" id="content"><?php echo stripslashes($result->body);?></textarea>
												</div>
												<div class="form-group">
													<label class="form-label">Meta Description  </label>
													<textarea name="meta_description" class="ckeditor admintextarea" rows="8" cols="30" id="content"><?php echo stripslashes($result->meta_description);?></textarea>
												</div>
												<div class="form-group">
													<label class="form-label">Featured Image </label>
													<input class="form-control" name="featured_images" type="file" required>
													<br/>
													<img src="uploads/pages/<?php echo $result->featured_images; ?>" height="100" width="100">
												</div>
												
												
												<div class="form-group">
													<label class="form-label">Status</label> 
													<div class=" right">
														<i class=""></i>
														<select class="form-control select2" id="cardType" name="status" data-init-plugin="select2" required>
															<option value="">Select Type</option>
															<option value="1"<?php if($result->status=='1') { ?>selected<?php } ?>>Published</option>
															<option value="0"<?php if($result->status=='0') { ?>selected<?php } ?>>Unpublished</option>
														</select>
													</div>
												</div>
												<div class="form-actions">
													<div class="pull-right">
														<button class="btn btn-success btn-cons" type="submit"><i class="icon-ok"></i> Save</button>
														<button class="btn btn-white btn-cons" type="button">Cancel</button>
													</div>
												</div>
											</form>
										</div>
									</div>
								</div>
								
							</div>
							<!---row--->
						</div>
					</div>
					<script data-cfasync="false" src="../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="assets/plugins/pace/pace.min.js" type="text/javascript"></script>
					
					<script src="assets/plugins/jquery/jquery-1.11.3.min.js" type="text/javascript"></script>
					<script src="assets/plugins/bootstrapv3/js/bootstrap.min.js" type="text/javascript"></script>
					<script src="assets/plugins/jquery-block-ui/jqueryblockui.min.js" type="text/javascript"></script>
					<script src="assets/plugins/jquery-unveil/jquery.unveil.min.js" type="text/javascript"></script>
					<script src="assets/plugins/jquery-scrollbar/jquery.scrollbar.min.js" type="text/javascript"></script>
					<script src="assets/plugins/jquery-numberAnimate/jquery.animateNumbers.js" type="text/javascript"></script>
					<script src="assets/plugins/jquery-validation/js/jquery.validate.min.js" type="text/javascript"></script>
					<script src="assets/plugins/bootstrap-select2/select2.min.js" type="text/javascript"></script>
					
					
					<script src="webarch/js/webarch.js" type="text/javascript"></script>
					<script src="assets/js/chat.js" type="text/javascript"></script>
					
					
					<script src="assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
					<script src="assets/plugins/boostrap-form-wizard/js/jquery.bootstrap.wizard.min.js" type="text/javascript"></script>
					
					<script src="assets/js/form_validations.js" type="text/javascript"></script>
					<script type="text/javascript" src="include/ckeditor/ckeditor.js"></script>
					
				</body>
			</body>
		</html>																											