<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>AAM AADMI PARTY’S 70 POINT ACTION PLAN </title>

  <!-- Bootstrap Core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom Fonts -->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">
  <link href="vendor/simple-line-icons/css/simple-line-icons.css" rel="stylesheet">

  <!-- Custom CSS -->
  <link href="css/stylish-portfolio.min.css" rel="stylesheet">

</head>

<body id="page-top">

  <!-- Navigation -->
 <!--
 <a class="menu-toggle rounded" href="#">
    <i class="fas fa-bars"></i>
  </a>
  <nav id="sidebar-wrapper">
    <ul class="sidebar-nav">
      <li class="sidebar-brand">
        <a class="js-scroll-trigger" href="#page-top">Start</a>
      </li>
      <li class="sidebar-nav-item">
        <a class="js-scroll-trigger" href="#page-top">Home</a>
      </li>
      <li class="sidebar-nav-item">
        <a class="js-scroll-trigger" href="#about">About</a>
      </li>
      <li class="sidebar-nav-item">
        <a class="js-scroll-trigger" href="#services">Services</a>
      </li>
      <li class="sidebar-nav-item">
        <a class="js-scroll-trigger" href="#portfolio">Portfolio</a>
      </li>
      <li class="sidebar-nav-item">
        <a class="js-scroll-trigger" href="#contact">Contact</a>
      </li>
    </ul>
  </nav> -->
  <!-- Header -->
  <header class="masthead d-flex">
    <div class="container text-center my-auto">
	 <div class="col-lg-12 col-md-6 mb-5 mb-lg-0">
          <span class="service-icon mx-auto mb-3">
            <img src="img/aaplogo.jpg" width="100%" />
          </span>
          <h4>
            <strong>AAP 2015-2019 </strong>
          </h4>
          
        </div>
	
      <h1 class="mb-1">2015 DELHI ASSEMBLY ELECTION </h1>
      <h3 class="mb-5">
        <em>AAM AADMI PARTY’S 70 POINT ACTION PLAN </em>
      </h3>
     <!--  <a class="btn btn-primary btn-xl js-scroll-trigger" href="#about">View Card</a> -->
    </div>
    <div class="overlay"></div>
  </header>

  <!-- About -->
  <section class="content-section bg-light" id="about">
    <div class="container text-center">
      <div class="row">
        <div class="col-lg-10 mx-auto">
          <h2>The Aam Aadmi Party was formed in the wake of a popular movement across the country for the creation of a strong and effective Lokpal to tackle corruption in high places.</h2>
          <p class="lead mb-5"> Heralding a new era of clean politics, AAP had a remarkable first electoral outing supported by the citizens of Delhi, which led to the first ever AAP government in Delhi. Unfortunately, the AAP government was defeated on the floor of the Delhi Assembly on February 14, 2014, when the BJP and the Congress joined hands to vote against the introduction of the Jan Lokpal Bill. The government led by Arvind Kejriwal decided to resign when it became clear that the Congress and the BJP would not allow the minority government of AAP to set up an independent and autonomous ombudsman.</p>
         <!-- <a class="btn btn-dark btn-xl js-scroll-trigger" href="#services">What We Offer</a> -->
        </div>
      </div>
    </div>
  </section>


  <!-- Portfolio -->
  <section class="content-section" id="portfolio">
    <div class="container">
      <div>
        <h2>However, 49 days were enough for AAP to show the common man what good governance is. AAP implemented all its poll promises in a time-bound manner: </h2>
      </div>
	  <hr>
	  <ul>
	  <li>Electricity bills for usage up to 400 units were halved.</li>
	  <li> An independent CAG audit of power discoms was ordered. </li>
 <li>Twenty kilolitres or 20,000 litres of lifeline water every month was made free. </li>
 <li>The water mafia was reined in and there was a crackdown on corruption in the Delhi Jal Board and all other government departments. The schedule of water tanker operations was made publicly available for the benefit of the citizens. </li>
 <li> Three FIRs were registered in scams related to Delhi Jal Board. Also 800 Delhi Jal Board employees were transferred and three senior officials were suspended.</li> 
 <li>Foreign Direct Investment (FDI) in retail was rolled back to protect traders and prevent the loss of jobs. </li>
 <li> The common man had a say in the implementation of MLA development funds through Mohalla Sabhas conducted by AAP MLAs. </li>
 <li>An SIT was ordered to provide justice to victims of the 1984 anti-Sikh killings. </li>
 <li> 5500 new auto permits were issued to members of the Scheduled Caste and Tribes, thus providing self-employment to deprived sections. </li>
 <li>An anti-corruption helpline was set up encouraging the citizens to identify instances of corruption and report them to law enforcement. This resulted in several officials being caught. More importantly, there was credible deterrence amongst the officials, which brought about a substantive decrease in the acts of corruption in the city. </li>
 <li> The "VIP" culture, a legacy from the British Raj, was abolished. No cars with red beacons, no special privileges for ministers were just some of the things that had been brought to a halt by our government. </li>
 <li> Fulfilling our commitment to the people working on contracts a committee was set up to make their jobs permanent. </li>
 <li> An FIR was registered against RIL Chairperson Shri Mukesh Ambani, former Union Petroleum Ministers M Veerappa Moily and Murli Deora and former DG Hydrocarbons VK Sibal in KG D6 scam. </li>
 <li> Rs 21 crore was disbursed in the form of education scholarships.</li>
 <li>An FIR was registered in CWG street lighting scam. </li>

	  </ul>
	  
	<br>  
	<div class="row">
<div class="col-md-6">
<h2>‘What we say is what we do’ was the creed that the AAP government lived by. We continue to live by that creed. </h2>
<p>
Elections beckon once again on 7 February 2015 and once again every political party will release its manifesto. Unfortunately, over time party manifestos have been reduced to insincere pledges promising everything to everybody, with very little follow-up in delivery after attainment of power. It has made the common man lose faith in political processes to see parties voted to power taking U-turns on the promises stated in their manifestos. This is where AAP crucially differs from all other political parties; it wants to restore the common man’s faith in our elected representatives and our democracy. <br><br>

For AAP, politics is an interactive process, a constant dialogue. Soon after the Delhi Vidhan Sabha was dissolved in the first week of November 2014, the party launched Delhi Dialogue, a unique initiative of drawing up the party manifesto by forging a partnership between the party and the citizens of Delhi. <br><br>

An honest, accountable and responsive political party seeks out people’s participation, instinctively sensing their immense potential to contribute to issues of governance by virtue of their everyday lived experience and professional knowledge. Delhi Dialogue is a policy-level intervention through which academicians, businesses, bureaucrats, elected officials, scholars of national and international repute, experts from various sectors and, most importantly, the Aam Aadmi of Delhi have come together to draw an action plan for Delhi’s future – our future. 

</p>
</div>	 

<div class="col-md-6">
<p>After holding hundreds of citizens’ meetings, organizing round tables with subject experts, marshaling responses gained from thousands of feedback forms, online comments, emailed suggestions, Whatsapp messages, Tweets and Facebook comments, AAP has drawn up a 70-point actionable plan for all sections of Delhi’s population – youth, women, traders, businesses, entrepreneurs, rural and urban villages, safai karmacharis, minorities, unauthorized and resettlement colonies, JJ clusters, RWAs, housing cooperatives and group housing societies. The perspectives and aspirations of Delhi’s citizens informed the debate on issues of power, water, health, education, housing, sanitation, employment, transport, social justice, women’s rights and safety, among others. There are certain issues that came up during the Delhi Dialogue that do not fall under the domain of the Delhi government. On such issues AAP will use its full moral and political authority to provide a much needed thought leadership to the nation. 
<br><br>
The aim of the Delhi Dialogue is to create an action plan for a Delhi that would reflect the aspirations of people from all walks of life:

<ul>
	<li> A Delhi that provides employment to all. </li>
<li> A Delhi provides high quality education to all. </li>
<li> A Delhi that ensures excellent healthcare to all. </li>
<li> A Delhi that is safe for women. </li>
<li> A Delhi that keeps pace with an ever increasing population’s demands for more roads, transport and traffic systems. </li>
<li> A Delhi that provides affordable electricity and clean drinking water to all its citizens. </li>
<li> A Delhi that provides essential services to all its citizens. </li>
<li> A Delhi proud of the Yamuna brought alive by clean water and beautiful riverbank. </li>
<li> A Delhi where all communities live together, secure in a social fabric that is inclusive and peaceful. </li>
<li> A Delhi that is pollution-free.</li>
<li> A Delhi where the citizen is made an equal stakeholder and voice in the city’s progress. </li>

</ul>

</p>
</div>	  
 </div>	
<br><br><br>
 <div>
  <h2>A Delhi that is prosperous, modern and progressive. Aam Aadmi Party will form a government that is transparent, participative and interactive in order to deliver this 70-point action plan:  </h2>
 </div>
 <br><br>
 <div class="card">
  <div class="card-body">
    <h5 class="card-title">1. Delhi Janlokpal Bill</h5>
    <p class="card-text">Aam Aadmi Party resolves to legislate the Delhi Jan Lokpal Bill after coming to power. This will ensure a time-bound investigation in matters of corruption. The Delhi Lokpal will have the power to initiate investigations and prosecution against those charged with corruption. A Citizens’ Charter shall be introduced in all government offices in Delhi. Whistleblowers will be provided protection and awarded for their contribution toward creating a just system.</p>
  </div>
</div>



 <div class="card">
  <div class="card-body">
    <h5 class="card-title">2. Swaraj Bill </h5>
    <p class="card-text">Aam Aadmi Party will legislate the Swaraj Act to devolve power directly to the people. Decisions affecting the local community will be taken by citizens and implemented by their Secretariat. A Citizen Local Area Development (C-LAD) Fund will be given to every Mohalla Sabha and Resident Welfare Association, ensuring funds and functions in the hands of the community. </p>
  </div>
</div>

 <div class="card">
  <div class="card-body">
    <h5 class="card-title">3. Full Statehood for Delhi </h5>
    <p class="card-text">Acting within the constitutional framework our government will use its moral and political authority to push for full statehood for Delhi. This will ensure that institutions such as the DDA, MCD and Delhi Police will be accountable to the elected government of Delhi. This way land will be made available for the common man, there will be greater synchronization and shared purpose among civic services with regard to service delivery and the law and order machinery will be accountable to the citizens.  </p>
  </div>
</div>

 <div class="card">
  <div class="card-body">
    <h5 class="card-title">4. Electricity Bills to be reduced by half </h5>
    <p class="card-text">An Aam Aadmi Party government will keep its promise of reducing electricity bills by half. A more efficient, transparent and accountable system to regulate and audit the power generation and distribution companies is the need of the hour and AAP will do everything within its command to achieve that. Discoms should purchase power from economical sources and wriggle out of expensive and unsustainable Power Purchase Agreements. AAP will take measures to provide relief from rising power bills, namely generating cheaper electricity, improving transmission efficiency, fixing billing defects and correcting meter defects.  </p>
  </div>
</div>

 <div class="card">
  <div class="card-body">
    <h5 class="card-title">5.	CAG Audit of Power Discoms </h5>
    <p class="card-text">We will conduct a comprehensive performance audit of discoms by the Comptroller and Auditor General of India. Discoms shall also be brought within the ambit of the RTI act. We will ensure that the citizens of Delhi do not have to bear the burden of soaring power tariffs. Initially we will provide subsidy that would go not to the power discoms but to Delhi Transco, a state-owned transmission company which has unpaid bills of Rs 3,500 crore to be paid by the discoms. This money will help Delhi Transco upgrade and augment its transmission capacity, which is in a bad state at present. The lack of funds at Transco’s disposal is one of the main reasons for the frequent power outages in the state. After the audit results are tabled in the assembly, power tariffs will be restructured. </p>
  </div>
</div>


 <div class="card">
  <div class="card-body">
    <h5 class="card-title">6.	Delhi’s Own Power Station </h5>
    <p class="card-text">We will put up Delhi's own power station at the pithead and comprehensively solve Delhi's electricity problem in the long run by being able to meet peak power consumption of 6200MW. We will also ensure that the Rajghat and Bawana plant are efficiently utilized.  </p>
  </div>
</div>


 <div class="card">
  <div class="card-body">
    <h5 class="card-title">7.	Introduce Competition Amongst Discoms</h5>
    <p class="card-text">AAP reiterates the promise made in its December 2013 Delhi manifesto of providing consumers the right to choose between electricity providers. We will introduce competitive distribution, which will provide better services and lead to lower tariffs.   </p>
  </div>
</div>

 <div class="card">
  <div class="card-body">
    <h5 class="card-title">8.	Delhi To Be Made A Solar City</h5>
    <p class="card-text">AAP will facilitate a phased shift to renewable and alternate sources of energy. Incentives will be given to households, housing societies, enterprise and industry to gradually switch over to renewable energy. We are committed to ensuring that 20 percent of Delhi’s energy needs are met through solar energy by 2025.  </p>
  </div>
</div>


 <div class="card">
  <div class="card-body">
    <h5 class="card-title">9.	Water As A Right</h5>
    <p class="card-text">AAP will provide Water as a Right. It will provide universal access to clean drinking water to all citizens of Delhi at an affordable price. The Delhi Jal Board Act will be amended to make clean drinking water a right of the people. AAP will make a time bound plan of action for covering all residents of Delhi with piped water and sewage network in all parts irrespective of their legal status. There will be no discrimination between planned/non-planned; authorized/ non-authorized; regularized/ non-regularized; city or village. Within five years piped water connections will be made available to as many as 14 lakh households (50 lakh people) in Delhi that do not have a piped water connection at present.   </p>
  </div>
</div>

 <div class="card">
  <div class="card-body">
    <h5 class="card-title">10.	Free Lifeline Water</h5>
    <p class="card-text">AAP will ensure free lifeline water of up to 20 kiloliters (20,000 liters) to every household per month through a Delhi Jal Board’s (DJB) metered water connection. This scheme will be extended to group-housing societies.   </p>
  </div>
</div>

 <div class="card">
  <div class="card-body">
    <h5 class="card-title">11.	Fair and Transparent Water Pricing</h5>
    <p class="card-text">AAP will provide universal access to potable water to all its citizens of Delhi at a sustainable and affordable price. The mandatory annual 10 percent hike in water tariffs will be abolished and any further hike will be made only after due consideration. The AAP government will abolish the C-1A (B) category to provide relief to households that run small shops from their residence (less than 100 square feet) for their livelihood for which they are charge commercial rates in spite of the fact that they are not using water for commercial purposes.  </p>
  </div>
</div>


 <div class="card">
  <div class="card-body">
    <h5 class="card-title">12.	Water From Munak Canal</h5>
    <p class="card-text">AAP will ensure the firm implementation of the High Court order that says Delhi is entitled to extra raw water from Haryana in the Munak canal, an issue on which the BJP government in Haryana and at the Centre have been dithering.  </p>
  </div>
</div>

 <div class="card">
  <div class="card-body">
    <h5 class="card-title">13.	Augmenting Water Resources</h5>
    <p class="card-text">Our government will preserve and replenish local and decentralized water resources, will initiate schemes for rainwater harvesting, recharge of wells, watershed development and soil-water conservation. AAP will revive Delhi’s water bodies like lakes, ponds and baolis, among others, by rainwater recharging and maintaining them in partnership with Mohalla Sabhas.  </p>
  </div>
</div>


 <div class="card">
  <div class="card-body">
    <h5 class="card-title">14.	Crackdown On Water Mafia</h5>
    <p class="card-text">AAP is committed to clamping down on Delhi’s powerful water mafia working under the patronage of political leaders. AAP will put in place a transparent tanker water distribution system by implementing state-of-the-art techniques. The schedule of tankers operating in different localities would be made available online and on mobile phone. Private tankers will be allowed to operate under the guidelines framed by our government. This will protect the consumers from exorbitant pricing and illegal practices of private tanker operators.   </p>
  </div>
</div>

 <div class="card">
  <div class="card-body">
    <h5 class="card-title">15.	Revive The Yamuna</h5>
    <p class="card-text">The Yamuna River has been part of the collective memory of Delhi for a long time but this lifeline is dying. We will ensure 100 percent collection and treatment of Delhi’s sewage through an extensive sewer network and construction of new functional sewage treatment plants. Discharge of untreated water and industrial effluents into the river Yamuna will be strictly prohibited.  </p>
  </div>
</div>

 <div class="card">
  <div class="card-body">
    <h5 class="card-title">16.	Promote Rainwater Harvesting</h5>
    <p class="card-text">The AAP government will throw its weight behind rainwater harvesting and strongly push it in a top-down manner. Families that adopt rainwater harvesting shall be termed water- friendly families. The government will provide incentives to families who do so.   </p>
  </div>
</div>


 <div class="card">
  <div class="card-body">
    <h5 class="card-title">17.	Build 2,00,000 Public Toilets</h5>
    <p class="card-text"> AAP will build two lakh toilets across Delhi: about 1.5 lakh toilets in slums and JJ clusters and 50,000 toilets in public spaces, of which 1 lakh toilets will be for women. These toilets will be concentrated in public spaces and slum areas. We will construct eco-toilets to save water.  </p>
  </div>
</div>

 <div class="card">
  <div class="card-body">
    <h5 class="card-title">18.	Better Waste Management</h5>
    <p class="card-text"> AAP will adopt and encourage the use of good practices in waste management techniques from across the world. We will encourage recycling by segregation of biodegradable and non-biodegradable waste at the household level. Littering or disposal of construction debris in public places will attract a heavy fine. We will enforce the ban on plastic bags in the city.  </p>
  </div>
</div>

 <div class="card">
  <div class="card-body">
    <h5 class="card-title">19.	Five Hundred New Government Schools</h5>
    <p class="card-text"> AAP will build 500 new schools with a special focus on secondary and senior secondary schools to ensure that every Delhi child has easy access to quality education.   </p>
  </div>
</div> 

<div class="card">
  <div class="card-body">
    <h5 class="card-title">20.	Higher Education Guarantee Scheme</h5>
    <p class="card-text"> Students who wish to pursue any diploma or degree course after finishing Class 12 from any school in Delhi will be given bank loans with the government standing as a guarantor. Students will not be required to furnish any collateral and the scheme will be universal in nature regardless of a student’s financial background. The loan will cover both tuition fees and living expenses. The loan repayment schedule will carry a moratorium period covering the years required to finish the course and one year thereafter to find a job. Under this scheme no loan request will be rejected.  </p>
  </div>
</div>

<div class="card">
  <div class="card-body">
    <h5 class="card-title">21.	Twenty New Degree Colleges</h5>
    <p class="card-text"> AAP will open 20 new colleges under Delhi administration on the outskirts of the city in partnership with the villages of Delhi. Further we will double the existing seat capacity of the Delhi government administered colleges including Delhi’s flagship university, the Ambedkar University.  </p>
  </div>
</div>

<div class="card">
  <div class="card-body">
    <h5 class="card-title">22.	Regulate Private School Fees</h5>
    <p class="card-text"> We will regulate private school fees by publishing the fee structures and accounts online. Capitation fee will be abolished.  </p>
  </div>
</div>

<div class="card">
  <div class="card-body">
    <h5 class="card-title">23.	Transparency in Schools Admissions</h5>
    <p class="card-text"> AAP will bring in complete transparency in Nursery and KG admissions. To streamline the admission process, we will use a centralized online system for nursery admissions, removing avenues for corruption. </p>
  </div>
</div>

<div class="card">
  <div class="card-body">
    <h5 class="card-title">24.	Ramp Up Government Schools to Provide Quality Education</h5>
    <p class="card-text">AAP is committed to improving the standard of government schools so that all citizens of Delhi have access to high quality of education. Every school will have sufficient functional toilets built, especially for girls. A sufficient budget will be given at the discretion of the principal for lights, fans, blackboards and other essential infrastructure. Teaching and learning infrastructure including computers and high-speed Internet connectivity will be made fully functional in every school. Number of DTC buses will be increased in order to service private schools so that it cuts down on the wait times at regular DTC bus stops. Seventeen thousand new teachers will be hired to maintain full staff strength at government schools. </p>
  </div>
</div>


<div class="card">
  <div class="card-body">
    <h5 class="card-title">25.	Increased Spending on Education and Healthcare</h5>
    <p class="card-text"> Education and Health will be AAP's top priority. The total budgetary allocation will be increased accordingly. </p>
  </div>
</div>


<div class="card">
  <div class="card-body">
    <h5 class="card-title">26.	Expand Healthcare Infrastructure</h5>
    <p class="card-text"> We will create 900 new Primary Health Centers (PHCs) and 30,000 more beds in Delhi hospitals, out of which 4,000 will be in maternity wards. We will ensure that Delhi conforms to the international norm of five beds for every 1000 people.  </p>
  </div>
</div>

<div class="card">
  <div class="card-body">
    <h5 class="card-title">27.	Quality Drugs For All At Affordable Price</h5>
    <p class="card-text">Pharmaceutical drug and equipment procurement will be centralized to ensure zero corruption. Generic, affordable and high quality drugs will be made available to the public.  </p>
  </div>
</div>

<div class="card">
  <div class="card-body">
    <h5 class="card-title">28.	Adequate Street Lighting</h5>
    <p class="card-text">Seventy percent of Delhi’s streetlights do not work. Unlit streets become scenes of crimes particularly against women. AAP will ensure a100 percent lighting of streets across the city so that no miscreant or anti-social activity goes unnoticed. </p>
  </div>
</div>


<div class="card">
  <div class="card-body">
    <h5 class="card-title">29.	Effective Last Mile Connectivity</h5>
    <p class="card-text">AAP will provide effective last mile connectivity in Delhi’s public transit system, which will play a role in reducing the number of crimes against women. An effective combination of shared autos, metro feeder services and e-rickshaws will be used to provide efficient last mile connectivity by fixing and delimiting routes. This will be synced with metro and bus timings so that there is a working connection to each neighborhood from nodal points.  </p>
  </div>
</div>

<div class="card">
  <div class="card-body">
    <h5 class="card-title">30.	CCTVs in Public Spaces and Buses</h5>
    <p class="card-text">AAP plans to install CCTV cameras in DTC buses, bus stands and in crowded places as a deterrent against crime. AAP will ensure that women can go about their jobs in the city free of stress while travelling by public transport.</p>
  </div>
</div>


<div class="card">
  <div class="card-body">
    <h5 class="card-title">31.	Speedy Justice through 47 Fast-Track Courts</h5>
    <p class="card-text">AAP will strongly push for the creation and completion of fast-track courts, which are dedicated to handling cases of sexual assault and other crimes against women. AAP will operationalize 47 new courts that it had commissioned in January 2014 to ensure speedy justice. If required, the courts will be run in two shifts so that the cases involving crimes against women are heard and trials completed within six months. </p>
  </div>
</div>

<div class="card">
  <div class="card-body">
    <h5 class="card-title">32.	Empower Delhi Lawyers and Judiciary</h5>
    <p class="card-text">New judges will be appointed. We will make provisions for affordable housing for government counsels and lawyers practising in lower courts. The government will streamline existing government medical schemes to ensure maximum coverage of legal functionaries.  </p>
  </div>
</div>

<div class="card">
  <div class="card-body">
    <h5 class="card-title">33.	Women’s Security Force</h5>
    <p class="card-text">AAP will set up Mahila Suraksha Dal or Women’s Security Force made up of a 10,000 strong Home Guard who are currently forced to work as servants, drivers and cooks at the residences of senior officers and ministers. AAP will also use 5,000 bus marshals to prevent and deter crime on public transport.  </p>
  </div>
</div>


<div class="card">
  <div class="card-body">
    <h5 class="card-title">34.	Suraksha Button</h5>
    <p class="card-text">Our government will provide a Suraksha/SOS button on every mobile phone. We will work towards its connectivity to the police, nearest PCR van, relatives and volunteer community. </p>
  </div>
</div>

<div class="card">
  <div class="card-body">
    <h5 class="card-title">35.	Governance On The Mobile Phone</h5>
    <p class="card-text">All government services and forms will be made available online and on the phone. Data on government projects, performance, accounts and personnel will be posted online. This will bring transparency and accountability in governance.  </p>
  </div>
</div>


<div class="card">
  <div class="card-body">
    <h5 class="card-title">36.	Delhi’s Villages To Receive Special Attention</h5>
    <p class="card-text">Decisions regarding the development of Delhi’s villages will be taken by Gram Sabhas, which will be granted special untied Village Development Funds to be utilized according to their priorities. Those engaged in agriculture and animal husbandry will receive incentives and infrastructural support as is done in neighbouring states. We will provide sports facilities in villages to encourage young adults to pursue sports. Connectivity to rural Delhi will be enhanced through increased bus and metro services.  </p>
  </div>
</div>


<div class="card">
  <div class="card-body">
    <h5 class="card-title">37.	Pro-Farmer Land Reform</h5>
    <p class="card-text">Section 33 and 81 of the Delhi Land Reform Act, which put unjust restrictions on farmers’ rights over their land, will be removed. No land will be acquired in Delhi’s villages without the consent of the Gram Sabha. Strong pressure would be exerted on the Central government to remove unnecessary restrictions regarding land use in villages. </p>
  </div>
</div>


<div class="card">
  <div class="card-body">
    <h5 class="card-title">38.	Wi-Fi Delhi</h5>
    <p class="card-text">We will make Wi-Fi freely available in public spaces across Delhi. Citywide Wi-Fi can help in bridging the digital divide. It will also provide an impetus to education, entrepreneurship, business, employment, and also tie in with women’s safety initiatives.  </p>
  </div>
</div>


<div class="card">
  <div class="card-body">
    <h5 class="card-title">39.	Delhi To Be Made A Trade And Retail Hub</h5>
    <p class="card-text">AAP will formulate trader-friendly policies and streamline rules and regulations for setting up and running businesses. We will simplify compliance and licensing for traders and put in place a system of single window clearance. We will also ensure that starting a trade or business in Delhi takes a maximum time of one week. As vital stakeholders the participation of traders in the framing of trade policies will be encouraged. </p>
  </div>
</div>

 <div class="card">
  <div class="card-body">
    <h5 class="card-title">40.	No FDI In Retail</h5>
    <p class="card-text">Our government will continue with its decision of not allowing FDI in retail in Delhi. </p>
  </div>
</div> 


<div class="card">
  <div class="card-body">
    <h5 class="card-title">41.	Lowest VAT Regime</h5>
    <p class="card-text">Delhi will have the lowest VAT regime in India. We will simplify VAT and other tax structures. One portion of the VAT collected from every locality and market will be used for the maintenance and upgradation of that market to foster business and trade.  </p>
  </div>
</div>

<div class="card">
  <div class="card-body">
    <h5 class="card-title">42.	End of VAT Raids And Inspector Raj</h5>
    <p class="card-text"> We will put an end to raid culture and inspector raj. Only under exceptional circumstances will a raid be permitted with the prior approval of senior officials.  </p>
  </div>
</div>

<div class="card">
  <div class="card-body">
    <h5 class="card-title">43.	Simplifying VAT Rules</h5>
    <p class="card-text">AAP will simplify VAT rules, processes and forms. The 30 page long VAT form will be crunched into one page for traders. All communication with the concerned department will be online. Licenses will be applied for and received at home.   </p>
  </div>
</div>

<div class="card">
  <div class="card-body">
    <h5 class="card-title">44.	Delhi Skill Mission</h5>
    <p class="card-text">AAP will promote vocational education and skill development of Delhi's youth in schools and colleges, to bridge the real skill gap in Delhi. We will create the first ever Delhi Skill Mission to train and enable one lakh youth per year for the first 2 years, ramping up to five lakh youth per year for the next 3 years. </p>
  </div>
</div>

 <div class="card">
  <div class="card-body">
    <h5 class="card-title">45.	Create 8 Lakh Jobs</h5>
    <p class="card-text">AAP will create eight lakh new jobs in the next five years. AAP will facilitate innovative and private startup accelerators to provide support to entrepreneurs. We will create an ecosystem that enables private industry to create more jobs. </p>
  </div>
</div>

 <div class="card">
  <div class="card-body">
    <h5 class="card-title">46.	Delhi To Be Startup Hub</h5>
    <p class="card-text">The government will encourage startups by setting up business and technology incubators in universities and colleges. As a pilot project, we will also create three million square feet of affordable business incubation space. </p>
  </div>
</div> 


<div class="card">
  <div class="card-body">
    <h5 class="card-title">47.	Contractual Posts To Be Regularized</h5>
    <p class="card-text">AAP will fill 55,000 vacancies in the Delhi government and autonomous bodies of the Delhi Government on an immediate basis. 4,000 doctors and 15,000 nurses and paramedics will be made permanent. </p>
  </div>
</div>


<div class="card">
  <div class="card-body">
    <h5 class="card-title">48.	Emphasis On Social Security</h5>
    <p class="card-text"> AAP will implement a flexible and fair labour policy. Our policy will ensure social security for workers in the unorganized sector; regulate wages, services and working hours of domestic workers and improve work conditions of rag pickers. Local Mohalla Sabhas will provide licences to street vendors and hawkers in designated spaces. </p>
  </div>
</div>

<div class="card">
  <div class="card-body">
    <h5 class="card-title">49.	Reducing Pollution</h5>
    <p class="card-text">  Delhi Ridge, the lung of the city, will be protected from encroachment and deforestation. Environmentally appropriate afforestation would be carried out in all parts of Delhi in collaboration with the local Mohalla Sabhas. We will acquire mechanized vacuum cleaning vehicles to clean the city. Public transport will be improved to reduce the number of cars on the road. Additionally, incentives will be provided for low emission fuels like CNG and electricity. Government will encourage car-pooling and will crackdown on fuel adulteration to reduce pollution.</p>
  </div>
</div>


<div class="card">
  <div class="card-body">
    <h5 class="card-title">50.	Unified Transport Authority</h5>
    <p class="card-text"> AAP will formulate holistic transport policies for all forms of transport including the metro, buses, auto rickshaws, rickshaws and e-rickshaws. A ‘Unified Transport Authority’ will be established for this purpose. </p>
  </div>
</div>

<div class="card">
  <div class="card-body">
    <h5 class="card-title">51.	Large Scale Expansion in Bus Services</h5>
    <p class="card-text">We will expand bus services in the city on a massive scale, adding at least 5,000 new buses to the city fleet in five years. This will reduce the cost of transportation and pollution in the city.  </p>
  </div>
</div>

<div class="card">
  <div class="card-body">
    <h5 class="card-title">52.	Just And Fair Policy For E-Rickshaws</h5>
    <p class="card-text"> E-rickshaw drivers of Delhi spent many months mired in confusion. They lost their livelihood for months due to the BJP’s policy paralysis. AAP will formulate a clear policy and standards for the ownership and operation of e-rickshaws, keeping safety aspects in mind. </p>
  </div>
</div>
 
<div class="card">
  <div class="card-body">
    <h5 class="card-title">53.	Metro Rail 2.0</h5>
    <p class="card-text"> We will collaborate with the Indian Railways to extend and develop the Ring Rail service in Delhi. AAP will also work towards large-scale expansion of the Delhi metro, especially in rural areas. Senior citizens, students and persons with disability will be provided concessional passes on buses and in the metro. </p>
  </div>
</div>


<div class="card">
  <div class="card-body">
    <h5 class="card-title">54.	Fair Arrangement for Auto Drivers</h5>
    <p class="card-text">The number of auto rickshaw stands will be increased. We will facilitate fast bank loans for the purchase of auto-rickshaws. Special trainings will be conducted for auto drivers to improve their overall conduct. The interests of commuters will be protected by taking strict action against auto drivers in case of violation of laws or misbehaviour. At the same time, we will prevent harassment of auto rickshaw drivers by the police.  </p>
  </div>
</div>
 
 <div class="card">
  <div class="card-body">
    <h5 class="card-title">55.	Freehold Of Resettlement Colonies</h5>
    <p class="card-text">The Aam Aadmi Party proposes a simple solution of conferring freehold rights to resettlement colonies. Original allottees will receive ownership of their plots for just Rs. 10,000. Those who are not original allottees will get the ownership rights of their plots for less than Rs. 50,000 depending on their plot size. The cumbersome multi-page form will be simplified and condensed into a single page form. </p>
  </div>
</div>  

<div class="card">
  <div class="card-body">
    <h5 class="card-title">56.	Regularization And Transformation Of Unauthorized Colonies</h5>
    <p class="card-text"> We will provide reistration rights with regard to property and sales deeds in resettlement colonies. Further, we will provide water and sewer lines, electricity, schools and hospitals in a systematic and phased manner. Multi-pronged action to make available these basic necessities is the only way of empowering unauthorized colonies, which is something that has never been attempted by the BJP or the Congress. Within one year of our government formation, these unauthorized colonies will be regularized and residents will be given ownership rights. </p>
  </div>
</div>

<div class="card">
  <div class="card-body">
    <h5 class="card-title">57.	Affordable Housing For All</h5>
    <p class="card-text"> We will construct affordable housing for lower income groups. Over 200 acres of land is currently lying vacant with the Delhi Urban Shelter Improvement Board that can be used for affordable housing.</p>
  </div>
</div> 

<div class="card">
  <div class="card-body">
    <h5 class="card-title">58.	In Situ Development of Slums</h5>
    <p class="card-text"> Slum dwellers will be provided plots or flats in the same location as the existing slums. If that is not possible, they will be rehabilitated in the closest possible location. The Mohalla Sabha will plan the rehabilitation process and monitor its implementation. Until such rehabilitation is completed, the slums will not be demolished under any circumstances. Facilities for drinking water, sanitation and cleaning of sewage canals will be provided in all slums. Streets and lanes in slums will be repaired and converted into pucca roads. </p>
  </div>
</div> 


<div class="card">
  <div class="card-body">
    <h5 class="card-title">59.	Taking Care Of Our Senior Citizens</h5>
    <p class="card-text"> The government will initiate a universal and non-contributory old age pension system immediately. A minimum dignified amount indexed to inflation will be provided. Delays in disbursement and arbitrary decisions regarding pensions will be eliminated.  </p>
  </div>
</div> 

<div class="card">
  <div class="card-body">
    <h5 class="card-title">60.	Controlling Price Rise</h5>
    <p class="card-text">  In the retail and wholesale business, stringent measures will be taken to prevent hoarding and profiteering. Our government will use the its full strength to stop black market operations, hoarding and speculative trading to curb the rising prices of vegetables, fruits and other essential commodities. Ration shops and the public distribution system will be corruption-free and shield the Aam Aadmi from rising costs.  </p>
  </div>
</div> 

<div class="card">
  <div class="card-body">
    <h5 class="card-title">61.	Drug-Free Delhi:</h5>
    <p class="card-text">AAP wishes to make Delhi a completely drug-free state. We will prevent drug trafficking by means of tight monitoring and ensuring strict punishment for the guilty. The number of de-addiction centers shall be increased and mental and psychiatric support for rehabilitation purposes will be provided. We will also ensure that effective counseling is easily available in schools for adolescents.  </p>
  </div>
</div> 

<div class="card">
  <div class="card-body">
    <h5 class="card-title">62.	Empowering The Disabled</h5>
    <p class="card-text">We are committed to protecting the rights of Persons with Disability (PwD), and hope to make Delhi an exemplar for the rest of India. AAP will ensure implementation of the 3 percent reservation for persons with disability. We will strive to make education truly inclusive by hiring special educators in government schools. AAP will help children with disability get admission into schools and colleges and ensure financial support to institutions working especially for their needs.  </p>
  </div>
</div> 

<div class="card">
  <div class="card-body">
    <h5 class="card-title">63.	Justice For Victims Of Anti-Sikh 1984 Carnage</h5>
    <p class="card-text">The 1984 anti-Sikh carnage was one of the lowest points in the history of Delhi. Those responsible continue to roam scot-free. The Aam Aadmi Party understands the feeling widespread in the Sikh community that they have been denied justice. Further, the fact that the BJP-led government at the Centre still feels the need to constitute a committee to decide whether an SIT is needed or not on this issue is mystifying. We promise to notify the SIT that we had ordered in January 2014 to reinvestigate the 1984 anti-Sikh killings, particularly the involvement of high profile Congress leaders. Cases where investigations were not carried out properly or witness testimonies not recorded will be reopened.   </p>
  </div>
</div> 

<div class="card">
  <div class="card-body">
    <h5 class="card-title">64.	Respecting Our Ex-Servicemen</h5>
    <p class="card-text">Delhi is home to a large number of ex-servicemen and women from the Armed Forces. AAP will stand by the nation’s ex-servicemen in their fight for “One Rank, One Pension”. We will ensure the existing quota in government jobs for ex-servicemen is filled up.  </p>
  </div>
</div> 

<div class="card">
  <div class="card-body">
    <h5 class="card-title">65.	Development And Equality For All Minorities</h5>
    <p class="card-text"> The recent communal tension witnessed in Delhi is totally out of sync with the social fabric of the city. We stand firmly against attacks on places of worship and inflammatory speeches across Delhi. Upholding the spirit of Swaraj, Mohalla Sabhas will set up peace committees to ensure harmony in their respective neighborhoods. We will bring transparency in the functioning of Delhi Waqf Board and ensure that encroachments on Waqf property by private parties as well as the government are removed.   </p>
  </div>
</div> 

<div class="card">
  <div class="card-body">
    <h5 class="card-title">66.	Dignity To The Safai Karamchari</h5>
    <p class="card-text"> AAP will end contractualisation in “safai karamchari” posts and will regularize existing employees. Workers who enter sewers will be provided with protective gear, masks and appropriate equipment. Like fire fighters, they will receive medical insurance. To help in their career advancement, safai karamcharis will be provided assistance in education and training. On the death of a “safai karamchari” on duty, Rs. 50 lakh will be given to the bereaved family.  </p>
  </div>
</div>


<div class="card">
  <div class="card-body">
    <h5 class="card-title">67.	Ensuring The Rights Of The Marginalized</h5>
    <p class="card-text"> We will ensure that policies of reservation concerning the Scheduled Castes, Scheduled Tribes and Other Backward Caste sections are enforced in Delhi government jobs. Entrepreneurs from Scheduled Castes will be provided zero or low-interest loans to set up businesses. Procedures for obtaining caste certificates will be simplified. We will take steps to end the discrimination against and harassment of denotified and nomadic communities in Delhi. The long neglected transgender community will be provided access to health, education and appropriate identity cards that will ease their engagement with institutions.  </p>
  </div>
</div> 


<div class="card">
  <div class="card-body">
    <h5 class="card-title">68.	Promote Sports Culture</h5>
    <p class="card-text">  We will create new sports facilities, improve the existing infrastructure and provide coaching assistance to sportspersons. We will open for the youth Delhi’s sports stadiums and complexes that at present are lying underutilized. More than 3000 government school playgrounds will also be made available to the local community after school hours.   </p>
  </div>
</div> 

<div class="card">
  <div class="card-body">
    <h5 class="card-title">69.	Promoting Punjabi, Sanskrit And Urdu</h5>
    <p class="card-text">   We will provide second-language status to Urdu and Punjabi. An adequate number of teachers will be employed for teaching Urdu and Punjabi. Research in Urdu and Punjabi shall be encouraged in various Delhi state universities. Study and research in Sanskrit will also be encouraged.  </p>
  </div>
</div> 

<div class="card">
  <div class="card-body">
    <h5 class="card-title">70.	Preserving Our Heritage and Literature</h5>
    <p class="card-text">  The Delhi Public Library Network, which presented a vibrant public space accessible to all and encouraged a culture of reading and curiosity about one’s social context, will be enhanced. A public library or community-reading space will be created in every constituency of Delhi.  </p>
  </div>
</div> 
 
 

    </div>
  </section>

  

  <!-- Footer -->
  <footer class="footer text-center">
    <div class="container">
      <ul class="list-inline mb-5">
        <li class="list-inline-item">
        <img src="img/aaplogo.jpg" width="200px" />
        </li> 
      </ul>
      <p class="text-muted small mb-0">2015 DELHI ASSEMBLY ELECTION</p>
    </div>
  </footer>

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded js-scroll-trigger" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Plugin JavaScript -->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for this template -->
  <script src="js/stylish-portfolio.min.js"></script>

</body>

</html>
