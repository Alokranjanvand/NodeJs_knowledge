<?php
	ob_start();
	@session_start();
	error_reporting(0);
	date_default_timezone_set("Asia/Calcutta");
	// server info
	$server = 'localhost';
	$user = 'root';
	$pass = 'ehs@#$987';
	$db = 'manifesto';
	$base_url = "http://localhost/ptl_cms/";
	$site_title = "Parahit CMS";
	// connect to the database
	$mysqli = new mysqli($server, $user, $pass, $db);
	if ($mysqli->connect_error) {
		die('Error : ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
	}
	else{
		
		//echo "DateBase Connected";
	}
	// show errors (remove this line if on a live site)
	mysqli_report(MYSQLI_REPORT_ERROR);
	define(SITE_URL,$base_url);
	define(SITE_TITLE,$site_title);
	
	/* Define dynamic table*/
	define(TBL_USER,"tbl_users");
    define(TBL_PAGES,"tbl_pages");
	define(CPASS_URL,"http://172.29.0.239/api/jwt-handler");
	
	
?>	