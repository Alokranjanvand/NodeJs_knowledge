<?php
	function buildURL($url){
		$newurl=str_replace(" - "," ",$url);
		$myurl=str_replace("--","-",str_replace("%","",str_replace(" ","-",str_replace("-"," ",trim($newurl)))));
		return stripslashes($myurl);
	}
	function parseInput($val) {
		return $mysqli->real_escape_string($val);
	}
	function clearCache() {
		header("Cache-Control: no-cache, must-revalidate");
		header("Expires: Mon, 26 Jul 2019 05:00:00 GMT");
	}
	function redirect($url) {
		header("location:$url");
		exit();
	}
	function ageCalculator($dob){
		if(!empty($dob)){
			$birthdate = new DateTime($dob);
			$today   = new DateTime('today');
			$age = $birthdate->diff($today)->y;
			return $age;
			}else{
			return 0;
		}
	}
	function validateAdminSession() {
		if(trim($_SESSION["sess_admin_id"])=="" && trim($_SESSION["sess_admin_logged"])!="true") {
			$_SESSION["sess_msg"] = "Session is expire. Please login again to continue";
			redirect("login.php");
		}
	}
	function showSessionMsg() {
		if(trim($_SESSION["sess_msg"])) {
			echo $_SESSION["sess_msg"];
			$_SESSION["sess_msg"] = "";
		}
	}
	
	function validate_admin()
	{
		if($_SESSION['sess_admin_id']=='')
		{
			ms_redirect("index.php?back=$_SERVER[REQUEST_URI]");
		}
	}
	function ms_redirect($file, $exit=true, $sess_msg='')
	{
		header("Location: $file");
		exit();
		
	}
	function sort_arrows($column){
		global $_SERVER;
		return '<A HREF="'.$_SERVER['PHP_SELF'].get_qry_str(array('order_by','order_by2'), array($column,'asc')).'"><IMG SRC="images/white_up.gif" BORDER="0"></A> <A HREF="'.$_SERVER['PHP_SELF'].get_qry_str(array('order_by','order_by2'), array($column,'desc')).'"><IMG SRC="images/white_down.gif" BORDER="0"></A>';
	}
	function sort_arrows1($column){
		global $_SERVER;
		return '<A HREF="'.$_SERVER['PHP_SELF'].get_qry_str(array('order_by','order_by2'), array($column,'asc')).'"><IMG SRC="admin/images/white_up.gif" BORDER="0"></A> <A HREF="'.$_SERVER['PHP_SELF'].get_qry_str(array('order_by','order_by2'), array($column,'desc')).'"><IMG SRC="admin/images/white_down.gif" BORDER="0"></A>';
	}
	function getUser(){
		global $mysqli;
		$q="select * from tbl_users where status=1 order by id desc";
		$result = $mysqli->query($q);
		return $result->num_rows;
	}
	function checkTemplate($user_id){
		global $mysqli;
		$q="select * from tbl_templates where user_id='{$user_id}'";
		$result = $mysqli->query($q);
		return $result->num_rows;
	}
	function sort_arrows_front($column,$heading){
		global $_SERVER;
		return '<A HREF="'.$_SERVER['PHP_SELF'].get_qry_str(array('order_by','order_by2'), array($column,'asc')).'"><img src="images/sort_up.gif" alt="Sort Up" border="0" title="Sort Up"></A>&nbsp;'.$heading.'&nbsp;<A HREF="'.$_SERVER['PHP_SELF'].get_qry_str(array('order_by','order_by2'), array($column,'desc')).'"><img src="images/sort_down.gif" alt="Sort Down" border="0" title="Sort Down"></A>';
	}
	function sort_arrows_front1($column,$heading){
		global $_SERVER;
		return '<A HREF="'.$_SERVER['PHP_SELF'].get_qry_str(array('order_by','order_by2'), array($column,'asc')).'"><img src="admin/images/sort_up.gif" alt="Sort Up" border="0" title="Sort Up"></A>&nbsp;'.$heading.'&nbsp;<A HREF="'.$_SERVER['PHP_SELF'].get_qry_str(array('order_by','order_by2'), array($column,'desc')).'"><img src="admin/images/sort_down.gif" alt="Sort Down" border="0" title="Sort Down"></A>';
	}
	/*--------Create function for encrypted Password--*/
	function EncryptPassword($string) {
		$encrypt_method = "AES-256-CBC";
		$secret_key = 'parahit@#Technology';
		$secret_iv = '128459633';
		$key = hash('sha256', $secret_key);
		$iv = substr(hash('sha256', $secret_iv), 0, 16);
		$output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
		$output = base64_encode($output);
		return $output;
	}
	/*--------Create function for decrypted Password--*/
	function DecryptPassword($string) {
		$encrypt_method = "AES-256-CBC";
		$secret_key = 'parahit@#Technology';
		$secret_iv = '128459633';
		// hash
		$key = hash('sha256', $secret_key);
		
		// iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
		$iv = substr(hash('sha256', $secret_iv), 0, 16);
		$output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
		return $output;
	}
	///show current date time
	function current_date()
	{
		$date = date('Y-m-d H:i:s');
		return $date;
	}
	function check_token_user($token = '') {
		$arr_data = array(
			"tag" => "token_decrypt",
			"token_id" => $token
		);
		$json_data = json_encode($arr_data);
		$curl = curl_init();
		curl_setopt_array($curl, array(
			CURLOPT_URL => CPASS_URL,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => '',
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 10, // don't let it hang forever
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => 'POST',
			CURLOPT_POSTFIELDS => $json_data,
			CURLOPT_HTTPHEADER => array(
				'Content-Type: application/json',
				'X-Authentication-Token: parahittechnoly@129883'
			),
		));
		$response = curl_exec($curl);
		$curl_error = curl_error($curl);
		$http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
		curl_close($curl);
	
		if ($curl_error) {
			return 0;
		}
	
		if ($http_code !== 200) {
			return 0;
		}
	
		
	
		if (json_last_error() !== JSON_ERROR_NONE) {
			// Handle JSON decode error
			error_log("JSON Decode Error: " . json_last_error_msg());
			return 0;
		}
		$arr = json_decode($response, true);
		if (isset($arr['data']['user_id'])) {
			return $arr['data']['user_id'];
		} else {
			// Something's missing in the response
			error_log("Unexpected Response Format: " . $response);
			return 0;
		}
	}
	
	
	
