<?php
	include("include/config.php");
	include("include/functions.php");
	validate_admin();
?>
<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
		<meta charset="utf-8" />
		<title><?php echo SITE_TITLE; ?></title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
		<meta content="" name="description" />
		<meta content="" name="author" />
		<script src="../../cdn-cgi/apps/head/QJpHOqznaMvNOv9CGoAdo_yvYKU.js"></script><link href="assets/plugins/font-awesome/css/font-awesome.css" rel="stylesheet" type="text/css" />
		<link href="assets/plugins/bootstrap-select2/select2.css" rel="stylesheet" type="text/css" media="screen" />
		<link href="assets/plugins/jquery-datatable/css/jquery.dataTables.css" rel="stylesheet" type="text/css" />
		<link href="assets/plugins/datatables-responsive/css/datatables.responsive.css" rel="stylesheet" type="text/css" media="screen" />
		<link href="assets/plugins/pace/pace-theme-flash.css" rel="stylesheet" type="text/css" media="screen" /> 
		<link href="assets/plugins/bootstrapv3/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
		<link href="assets/plugins/bootstrapv3/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css" />
		<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
		<link href="assets/plugins/animate.min.css" rel="stylesheet" type="text/css" />
		<link href="assets/plugins/jquery-scrollbar/jquery.scrollbar.css" rel="stylesheet" type="text/css" />
		<link href="webarch/css/webarch.css" rel="stylesheet" type="text/css" />
	</head>
	
	
	<body class="">
		<div class="header navbar navbar-inverse ">
			<div class="navbar-inner">
				<?php include('header.php');?>
				<div class="page-container row">
					<?php include('sidebar.php');?>
					<div class="page-content">
						<div id="portlet-config" class="modal hide">
							<div class="modal-header">
								<button data-dismiss="modal" class="close" type="button"></button>
								<h3>Widget Settings</h3>
							</div>
							<div class="modal-body"> Widget settings form goes here </div>
						</div>
						<div class="clearfix"></div>
						<div class="content">
							<ul class="breadcrumb">
								<li>
									<p>YOU ARE HERE</p>
								</li>
								<li><a href="#" class="active">Form layouts & Validations</a> </li>
							</ul>
							<div class="page-title"> <i class="icon-custom-left"></i>
								<h3>Form - <span class="semi-bold">Validations</span></h3>
							</div>
							<div class="row">
								<div class="col-md-12">
									<div class="grid simple form-grid">
										<div class="grid-title no-border">
											<h4>Traditional <span class="semi-bold">Validation</span></h4>
											<div class="tools">
												<a href="javascript:;" class="collapse"></a>
												<a href="#grid-config" data-toggle="modal" class="config"></a>
												<a href="javascript:;" class="reload"></a>
												<a href="javascript:;" class="remove"></a>
											</div>
										</div>
										<div class="grid-body no-border">
											<table class="table table-hover table-condensed" id="example">
												<thead>
													<tr>
														<th style="width:1%">
															<div class="checkbox check-default" style="margin-right:auto;margin-left:auto;">
																<input type="checkbox" value="1" id="checkbox1">
																<label for="checkbox1"></label>
															</div>
														</th>
														<th style="width:10%">Project Name</th>
														<th style="width:22%" data-hide="phone,tablet">Description</th>
														<th style="width:6%">Price</th>
														<th style="width:10%" data-hide="phone,tablet">Progress</th>
													</tr>
												</thead>
												<tbody>
													
													<tr>
														<td>
															<div class="checkbox check-default">
																<input type="checkbox" value="3" id="checkbox7">
																<label for="checkbox7"></label>
															</div>
														</td>
														<td>Zombies</td>
														<td class="v-align-middle"><span class="muted">frequently involving research or design</span></td>
														<td><span class="muted">$6,000</span></td>
														<td>
															<div class="progress ">
																<div data-percentage="42%" class="progress-bar progress-bar-warning animate-progress-bar"></div>
															</div>
														</td>
													</tr>
													<tr>
														<td>
															<div class="checkbox check-default">
																<input type="checkbox" value="3" id="checkbox8">
																<label for="checkbox8"></label>
															</div>
														</td>
														<td>Zombies</td>
														<td class="v-align-middle"><span class="muted">frequently involving research or design</span></td>
														<td><span class="muted">$6,000</span></td>
														<td>
															<div class="progress ">
																<div data-percentage="42%" class="progress-bar progress-bar-warning animate-progress-bar"></div>
															</div>
														</td>
													</tr>
													<tr>
														<td>
															<div class="checkbox check-default">
																<input type="checkbox" value="3" id="checkbox9">
																<label for="checkbox9"></label>
															</div>
														</td>
														<td>Zombies</td>
														<td class="v-align-middle"><span class="muted">frequently involving research or design</span></td>
														<td><span class="muted">$6,000</span></td>
														<td>
															<div class="progress ">
																<div data-percentage="42%" class="progress-bar progress-bar-warning animate-progress-bar"></div>
															</div>
														</td>
													</tr>
													<tr>
														<td>
															<div class="checkbox check-default">
																<input type="checkbox" value="3" id="checkbox10">
																<label for="checkbox10"></label>
															</div>
														</td>
														<td>Zombies</td>
														<td class="v-align-middle"><span class="muted">frequently involving research or design</span></td>
														<td><span class="muted">$6,000</span></td>
														<td>
															<div class="progress ">
																<div data-percentage="42%" class="progress-bar progress-bar-warning animate-progress-bar"></div>
															</div>
														</td>
													</tr>
													<tr>
														<td>
															<div class="checkbox check-default">
																<input type="checkbox" value="3" id="checkbox11">
																<label for="checkbox11"></label>
															</div>
														</td>
														<td>Zombies</td>
														<td class="v-align-middle"><span class="muted">frequently involving research or design</span></td>
														<td><span class="muted">$6,000</span></td>
														<td>
															<div class="progress ">
																<div data-percentage="42%" class="progress-bar progress-bar-warning animate-progress-bar"></div>
															</div>
														</td>
													</tr>
													<tr>
														<td>
															<div class="checkbox check-default">
																<input type="checkbox" value="3" id="checkbox12">
																<label for="checkbox12"></label>
															</div>
														</td>
														<td>Zombies</td>
														<td class="v-align-middle"><span class="muted">frequently involving research or design</span></td>
														<td><span class="muted">$6,000</span></td>
														<td>
															<div class="progress ">
																<div data-percentage="42%" class="progress-bar progress-bar-warning animate-progress-bar"></div>
															</div>
														</td>
													</tr>
													<tr>
														<td>
															<div class="checkbox check-default">
																<input type="checkbox" value="3" id="checkbox13">
																<label for="checkbox13"></label>
															</div>
														</td>
														<td>Zombies</td>
														<td class="v-align-middle"><span class="muted">frequently involving research or design</span></td>
														<td><span class="muted">$6,000</span></td>
														<td>
															<div class="progress ">
																<div data-percentage="42%" class="progress-bar progress-bar-warning animate-progress-bar"></div>
															</div>
														</td>
													</tr>
													<tr>
														<td>
															<div class="checkbox check-default">
																<input type="checkbox" value="3" id="checkbox14">
																<label for="checkbox14"></label>
															</div>
														</td>
														<td>Zombies</td>
														<td class="v-align-middle"><span class="muted">frequently involving research or design</span></td>
														<td><span class="muted">$6,000</span></td>
														<td>
															<div class="progress ">
																<div data-percentage="42%" class="progress-bar progress-bar-warning animate-progress-bar"></div>
															</div>
														</td>
													</tr>
												</tbody>
											</table>
										</div>
									</div>
								</div>
							</div><!---row--->
						</div>
					</div>
					<script src="assets/plugins/pace/pace.min.js" type="text/javascript"></script>
					<script src="assets/plugins/jquery/jquery-1.11.3.min.js" type="text/javascript"></script>
					<script src="assets/plugins/bootstrapv3/js/bootstrap.min.js" type="text/javascript"></script>
					<script src="assets/plugins/jquery-block-ui/jqueryblockui.min.js" type="text/javascript"></script>
					<script src="assets/plugins/jquery-unveil/jquery.unveil.min.js" type="text/javascript"></script>
					<script src="assets/plugins/jquery-scrollbar/jquery.scrollbar.min.js" type="text/javascript"></script>
					<script src="assets/plugins/jquery-numberAnimate/jquery.animateNumbers.js" type="text/javascript"></script>
					<script src="assets/plugins/jquery-validation/js/jquery.validate.min.js" type="text/javascript"></script>
					<script src="assets/plugins/bootstrap-select2/select2.min.js" type="text/javascript"></script><script src="webarch/js/webarch.js" type="text/javascript"></script>
					<script src="assets/js/chat.js" type="text/javascript"></script><script src="assets/plugins/bootstrap-select2/select2.min.js" type="text/javascript"></script>
					<script src="assets/plugins/jquery-datatable/js/jquery.dataTables.min.js" type="text/javascript"></script>
					<script src="assets/plugins/jquery-datatable/extra/js/dataTables.tableTools.min.js" type="text/javascript"></script>
					<script type="text/javascript" src="assets/plugins/datatables-responsive/js/datatables.responsive.js"></script>
					<script type="text/javascript" src="assets/plugins/datatables-responsive/js/lodash.min.js"></script>
					<script src="assets/js/datatables.js" type="text/javascript"></script>
				</body>
			</body>
		</html>																															